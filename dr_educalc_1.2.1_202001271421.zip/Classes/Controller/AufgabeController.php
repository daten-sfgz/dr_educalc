<?php
namespace Dr\DrEducalc\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Annotation as Extbase;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility ;

/***
 *
 * This file is part of the "EduCalc" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * AufgabeController
 */
class AufgabeController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * aufgabeRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\AufgabeRepository
     * @Extbase\Inject
     */
    protected $aufgabeRepository = null;

    /**
     * materialRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\MaterialRepository
     * @Extbase\Inject
     */
    protected $materialRepository = null;

    /**
     * kategorieRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\KategorieRepository
     * @Extbase\Inject
     */
    protected $kategorieRepository = null;

    /**
     * formulaUtility
     *
     * @var \Dr\DrEducalc\Utility\FormulaUtility
     */
    protected $formulaUtility = null;

    /**
     * execiseUtility
     *
     * @var \Dr\DrEducalc\Utility\ExeciseUtility
     */
    protected $execiseUtility = null;

    /**
     * datahandlerUtility
     *
     * @var \Dr\DrEducalc\Utility\DatahandlerUtility
     */
    protected $datahandlerUtility = null;

    /**
     * constructor
     *
     * @return void
     */
    public function initializeAction()
    {
		$this->formulaUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\FormulaUtility');
		$this->execiseUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\ExeciseUtility');
		$this->datahandlerUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\DatahandlerUtility');
		$this->sessionUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\SessionUtility');
		
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		
		$this->configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$this->pages = $this->configurationManager->getContentObject()->data['pages'];
		if( !$this->pages ) $this->pages = $this->datahandlerUtility->enrichPagesWithStoragePidsFromTs( $this->pages ) ;
		
		if( $this->pages ) {
            $querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $querySettings->setRespectStoragePage( true );
            $querySettings->setStoragePageIds( explode(',',$this->pages) );
            $this->aufgabeRepository = $objectManager->get('Dr\\DrEducalc\\Domain\\Repository\\AufgabeRepository');
            $this->aufgabeRepository->setDefaultQuerySettings($querySettings);
            $this->kategorieRepository = $objectManager->get('Dr\\DrEducalc\\Domain\\Repository\\KategorieRepository');
            $this->kategorieRepository->setDefaultQuerySettings($querySettings);
            $this->materialRepository = $objectManager->get('Dr\\DrEducalc\\Domain\\Repository\\MaterialRepository');
            $this->materialRepository->setDefaultQuerySettings($querySettings);
        }
    }

    /**
     * initializeListAction
     *
     * @return void
     */
    public function initializeListAction()
    {
        if( $this->request->hasArgument('pdf') ) {
			$this->forward('print');
		}
    }

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
		// Update the group-field in multiple recordsets
		if( $this->request->hasArgument('aufgabe') && ( $this->request->hasArgument('save') || $this->request->hasArgument('pdf') ) ){
            $this->datahandlerUtility->updateMultipleRowsInRepository( $this->request->getArgument('aufgabe') , 'gruppe' ,  $this->aufgabeRepository );
		}
		
		// Move up or down in list
        if( $this->request->hasArgument('aufgabeUid') && $this->request->hasArgument('move') ) {
            // move on filtered recordsets. This has to be done again later.
            $sessFilter = $this->datahandlerUtility->getSessDataForPids( 'kategorie' , $this->pages );
			$this->datahandlerUtility->moveObjectOnGivenArray(
                $this->request->getArgument('aufgabeUid') ,
                $this->request->getArgument('move') , 
                $this->aufgabeRepository ,
                $this->aufgabeRepository->findAllBySubtable( $sessFilter , 'aufKat' , false , 'OR' )
			);
		
		}
		
		// Selectors: read all possible recordsets
		$aAllAufgabes = $this->aufgabeRepository->findAll();
        // get items for filter-selector
		$aFlt = $this->datahandlerUtility->getUsedKategorienFilter( $aAllAufgabes ) ;
        $this->view->assign('filter', $aFlt );
        // get items for group-selector to edit groups in multiple recordsets
        $aOptions = $this->datahandlerUtility->getAufgabeGruppeOptions( $aAllAufgabes );
        $this->view->assign('group_options', $aOptions);
        
        // Filter the recordsets (maybe done before, repeat now) and assign to aufgabes
//         $sessFilter = $this->sessionUtility->getData( 'kategorie' );
        $sessFilter = $this->datahandlerUtility->getSessDataForPids( 'kategorie' , $this->pages );
        $aAufgabes = $this->aufgabeRepository->findAllBySubtable( $sessFilter , 'aufKat' , false , 'OR' );
        $this->view->assign('aufgabes', $aAufgabes);
        
		// PDF-Outputs: get settings with markers
		// Only required for the first call! On later calls the fields are feeded by ajax
        if( $this->request->hasArgument('pdfsetting') ){
                $aPdfSetttings = $this->request->getArgument('pdfsetting');
        }else{
                $aPdfSetttings = [
                    'marker'=>[] , 
                    'amount'=> $this->settings['amount'] , 
                    'grouped'=>'' , 
                    'tailrows'=>$this->settings['tailrows'] , 
                    'titel'=> $this->settings['titel'] , 
                    'dauer'=> $this->settings['dauer'] , 
                    'bewertung'=> $this->settings['bewertung'] , 
                    'hilfsmittel'=> $this->settings['hilfsmittel'], 
                    'hintwidth'=> $this->settings['hintwidth']
                ];
        }
        $this->view->assign('pdfsetting', $aPdfSetttings );

        $this->view->assign('pages', $this->pages );
    }

    /**
     * action new
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @return void
     */
    public function newAction()
    {
        
//         $aSubTableRepository['mat'] = $this->materialRepository->findByVersteckt( 0 ) ;
//         $aSubTableRepository['kat'] = $this->kategorieRepository->findByVersteckt( 0 ) ;
//         $aSelections['tables']  = $this->datahandlerUtility->getMnTablesForCheckboxes( [] , $aSubTableRepository );
//         $this->view->assign('selections', $aSelections );

    }

    /**
     * action create
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @return void
     */
    public function createAction(\Dr\DrEducalc\Domain\Model\Aufgabe $newAufgabe)
    {
        if( $this->request->hasArgument('abort') ) $this->forward('list');
		
        if( trim( $newAufgabe->getTitel() ) == '' ) $newAufgabe->setTitel( 'neue Aufgabe' );
        
		if( $this->pages ) {
            $aPid = explode( ',' , $this->pages );
            $newAufgabe->setPid( $aPid[0] );
		}
        
        $this->aufgabeRepository->add($newAufgabe);
		$this->persistenceManager->persistAll();

        $this->addFlashMessage('Die neue Aufgabe wurde erstellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		
		$this->redirect('edit',null,null,array('aufgabe' => $newAufgabe));

    }

	/**
	 * duplicateAction
	 *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
	 * @return void
	 */
	public function duplicateAction(\Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe) {
            $newAufgabe = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Dr\DrEducalc\Domain\Model\Aufgabe');
            
            $properties = $aufgabe->_getProperties();
            
            $oldUid = $properties['uid'];
            unset($properties['uid']) ;

            $properties['titel'] = 'K' . $oldUid . ' ' . $properties['titel'];
            $properties['crdate'] = time();
            $properties['timestamp'] = time();

            foreach ($properties as $key => $value ) $newAufgabe->_setProperty( $key , $value );
            $this->aufgabeRepository->add( $newAufgabe );
            $this->persistenceManager->persistAll();
            
            $this->addFlashMessage('Die Aufgabe #' . $oldUid . ' wurde dupliziert zu #'.$newAufgabe->getUid().'.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            
			$this->forward( 'edit' , null , null , [ 'aufgabe' => $newAufgabe ] );
	}

    /**
     * action edit
     *
     * @Extbase\IgnoreValidation("aufgabe")
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @return void
     */
    public function editAction( \Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe )
    {
        $this->view->assign('aufgabe', $aufgabe);
        $this->view->assign('settings', $this->settings );
        
        // Pager: list all records to render them as links
        $this->view->assign('aAufgabes' , 
                $this->aufgabeRepository->findAllBySubtable( $this->datahandlerUtility->getSessDataForPids( 'kategorie' , $this->pages ) , 'aufKat' , false , 'OR' ) 
        );
        
        // Evaluate formulas for this record
        $aMultipleFormeln = $this->formulaUtility->getMultipleFormulasForExercise( $aufgabe , 1 , false );
        
        $this->view->assign('formulas', $aMultipleFormeln[1] );
        
        $this->view->assign('validation', $this->datahandlerUtility->validateAufgabe( $aufgabe , $aMultipleFormeln[1]['variables'] ) );
        
        // Selections antwort and tables:
        $aSelections = [];
        // antwort: options for select-field antwort: build list of variable-names
            $aVsort = [];
            if( is_array($aMultipleFormeln[1]['variables']) ) { 
                foreach( array_keys( $aMultipleFormeln[1]['variables'] ) as $variableName ) $aVsort[] = $variableName; 
                krsort($aVsort);
                foreach( $aVsort as $variableName ) $aSelections['antwort'][$variableName] = $variableName . ' (' . $aMultipleFormeln[1]['variables'][$variableName] . ')'; 
            }
        // tables: checkboxes to select Material and Category from n:m-tables
            // collect registered material and kategorie tables (registered in Aufgabe)
            $aSubTableRepository = [ 
                    'mat' => $aufgabe->getAufMat() , 
                    'kat' => $aufgabe->getAufKat() 
            ];
            // add ALL material and kategorie tables, also NOT registered in Aufgabe. Marked by different configuration
            $aAllTableRepository = [ 
                    'mat' => $this->materialRepository->findAllByPid( $this->pages ) , 
                    'kat' => $this->kategorieRepository->findAllByPid( $this->pages ) 
            ];
            $aSelections['tables']  = $this->datahandlerUtility->getMnTablesForCheckboxes( $aSubTableRepository , $aAllTableRepository );
        $this->view->assign('selections', $aSelections );
        
    }

    /**
     * initializeUpdateAction
     *
     * @return void
     */
    public function initializeUpdateAction()
    {
        if( $this->request->hasArgument('abort') ) {
			$this->forward('list');
		}
    }

    /**
     * action update
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @return void
     */
    public function updateAction(\Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe)
    {
        if( $this->request->hasArgument('delete') ) {
			$this->forward('delete',null,null,array('aufgabe' => $aufgabe));
		}
		
		// validate if formula field does not contain vulnerable code and material table has acceptable values
		
        if( false == $this->formulaUtility->execValidateFormula( $aufgabe ) ){
                $this->addFlashMessage('Aufgabe »' . $aufgabe->getUid() . '« NICHT gespeichert.', 'Nicht gespeichert', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
                $this->addFlashMessage( $this->formulaUtility->errorMessage  , 'Fehler in Formelfeld' , \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
                $this->redirect('edit',null,null,array('aufgabe' => $aufgabe));
        }
		
        if( $this->request->hasArgument('dupliz') ) {
			$this->redirect('duplicate',null,null,array('aufgabe' => $aufgabe));
		}
		
		// dont allow empty title (workaround for tricky validation in coherence with redirecting
        $titel = trim( $aufgabe->getTitel() );
        if( empty( $titel) ) $aufgabe->setTitel( 'Aufgabe Nr. ' . $aufgabe->getUid() );
        
        $this->addFlashMessage('Die Aufgabe »' . $aufgabe->getUid() . '« wurde gespeichert.', 'Gespeichert', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        $this->aufgabeRepository->update($aufgabe);

        if( $this->request->hasArgument('okclose') ) {
			$this->redirect('list');
		}
		
		$this->redirect('edit',null,null,array('aufgabe' => $aufgabe));
    }

    /**
     * action delete
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @return void
     */
    public function deleteAction(\Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe)
    {
        $this->addFlashMessage('Die Aufgabe »' . $aufgabe->getUid() . '« wurde gelöscht.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->aufgabeRepository->remove($aufgabe);
        $this->redirect('list');
    }

    /**
     * printAction
     *
     * @param array $pdfsetting
     * @return array
     */
    Public function printAction( $pdfsetting )
    {
		$linesAfterExercise = $pdfsetting['tailrows'];
		
		
		$aufgabes = $this->aufgabeRepository->findAll();
		$aCalcs = $this->execiseUtility->getExamesList( $aufgabes , $pdfsetting ) ;
		
		if( !count($aCalcs) )  $this->redirect('list');
		
		$documentname = LocalizationUtility::translate('tx_dreducalc.serialprint.documentname','dr_educalc') . '_' . date( 'Ymd_Hi' );
		$docutitle = LocalizationUtility::translate('tx_dreducalc.serialprint.title','dr_educalc');
		
		$aOutType = $this->request->getArgument('pdf');
		$outputType = isset( $aOutType['open'] ) ? 'I' : 'D';
	    
	    $pdf = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\PdfUtility');
		$ghost = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\PdfUtility');
		
		$LlTitle = $pdf->localchars( $docutitle );
		
		$pageConf = [ 
                'title' =>  $LlTitle , 
                'subject' =>  $documentname . '.pdf' , 
                'imagePath' => GeneralUtility::getFileAbsFileName( $this->settings['logo_pfad'] ) , 
                'bottomMargin' => 25 ,
                'leftMargin' => 35.5 
        ];
		// 24.7 Start bei linker Kante des Wappens
		// 35.5 Start bei Text Schule...
		
		$pdf->initializePdf($pageConf);
		
		$ghost->initializePdf($pageConf);
        
		$H = $pdf->pageConf['lfeed'];
		$addLines = ( $linesAfterExercise + 2 ) * $H;

		$aPtMax = [];
		foreach( $aCalcs as $PrfNr => $frage ){
              foreach( $frage as $FrgNr => $frageRow ){
                    $aPtMax[$PrfNr][] = $frageRow['antwort']['Punkte'];
              }
		}
		$hintWidth = $pdfsetting['hintwidth'] ? $pdfsetting['hintwidth']  : 130;
		foreach( $aCalcs as $PrfNr => $frage ){
            
            // start paginating for each students document
            $pdf->StartPageGroup();
            $pdf->AddPage();
            
            // leading page for each students document
            $prologueStrings = [ 'titel' , 'dauer' , 'bewertung' , 'hilfsmittel' ];
            $sr = [ '#VERSION#' => $PrfNr , '#ANZAHL#' => array_sum($aPtMax[$PrfNr]) ];
            
            $y = $pdf->GetY();
            
            $pdf->SetRightMargin( 210 - $hintWidth );
            
            foreach( $prologueStrings as $str ) {
            
                $rawString = str_replace( array_keys($sr) , $sr , $pdfsetting[$str] );
                if( '' == trim($rawString) ) continue;
                $aPrologue[$str] = $pdf->localchars( $rawString );
                
                $pdf->WriteHTML( $aPrologue[$str] );
                $pdf->Ln();
            
            }
            $yEnd = $pdf->GetY();
            $pdf->SetRightMargin( $pdf->pageConf['rightMargin'] );
            $pdf->Ln(0);
            
            $pdf->SetXY( $hintWidth , $y );
            $pdf->Cell( 0 ,  $H , 'Name:' , 'B' ,1 );
            $pdf->Ln();
            $pdf->SetX( $hintWidth  );
            $pdf->Cell( 0 ,  $H , 'Datum:'   , 'B' ,1 );
            $pdf->Ln();
            $pdf->SetX( $hintWidth  );
            $pdf->Cell( 0 ,  $H , 'Erreicht/Note:'   , '' ,1 );
            
            $pdf->SetY( $yEnd - $H);
            $pdf->Cell( 0 ,  $H / 2 , ''   , 'B' ,1 );
            $pdf->Cell( 0 ,  $H / 2 , ''   , '' ,1 );
            
            foreach( $frage as $FrgNr => $frageRow ){
                // evaluate if pagebreak is affored
                $height = $ghost->getHtmlSize( $frageRow['text']['Aufgabe'] ) ;
                $posEnd = $pdf->pageConf['bottomMargin'] + $pdf->GetY() + $height + $addLines;
                if( $posEnd > 297 ) {
                    $pdf->AddPage();
                    $pdf->Cell( 0 , $H , 'Folgeseite von ' . $pdf->localchars('Version') . ' ' . $PrfNr  , '' ,1 );
                }
                
                // write the lines
                $pdf->WriteHTML( '<b>' . $FrgNr . ') ' . $pdf->localchars( $frageRow['text']['Titel'] ) . '</b> (' . $frageRow['antwort']['Punkte']  . ' Pt.)' );
                $pdf->Ln();
                $pdf->WriteHTML( $pdf->localchars( $frageRow['text']['Aufgabe'] ) );
                $pdf->Ln( $linesAfterExercise * $H );
            }
            // students document finished
		}
		
		// Appendix
        $pdf->StartPageGroup();
        $pdf->AddPage();

		$pdf->mkTitle( $pdf->localchars( 'Lösungen ' . count($aCalcs) . ' Versionen' ) );
		
		$stegBreite = 6;
		$spaltenBreite = (210 - ($pdf->pageConf['leftMargin']+$pdf->pageConf['rightMargin']) ) / 2 ;
		$spaltenBreite -= ($stegBreite/2);

		foreach( $aCalcs as $PrfNr => $frage ){
            
            // write 2 cells at once
            $firstColRowsAmount = ceil( count($frage) / 2 );
            
            // evaluate if there is enough space for the exame
            $height = $H * ( $firstColRowsAmount + 2 );
            $posEnd = $pdf->pageConf['bottomMargin'] + $pdf->GetY() + $height;
            if( $posEnd >= 297 ) $pdf->AddPage();
            
            $pdf->SetFont( $pdf->pageConf['fontfamily'] , 'B' , $pdf->pageConf['fsize'] );
            $strTit = $pdf->localchars('Lösungen von Prüfung Version') . ' ' . $PrfNr . '.';
            $titBreite = $pdf->GetStringWidth( $strTit );
            $pdf->Cell( $titBreite , $H ,  $strTit  , '' , 0 );
            $pdf->SetFont( $pdf->pageConf['fontfamily'] , '' , $pdf->pageConf['fsize'] );
            $strSubtit = ' Max. '. array_sum($aPtMax[$PrfNr]) . ' Punkte.';
            $pdf->Cell( 0 , $H ,   $strSubtit , '' ,1 );
            
            for( $frageLinksNr = 1 ; $frageLinksNr <= $firstColRowsAmount ; ++$frageLinksNr ) {
                    
                    $frageRechtsNr = $frageLinksNr + $firstColRowsAmount;
                    $frageRowLinks = $frage[$frageLinksNr];
                    $frageRowRechts = $frage[$frageRechtsNr];
                    
                    $str = $frageLinksNr . ') ';
                    $leadWidth = $pdf->GetStringWidth( $str );
                    $minPtL = round( (100 - $this->settings['gewichtung_einheit_prozent']) * $frageRowLinks['antwort']['Punkte'] / 100 , 2 );
                    $maxPtL = $frageRowLinks['antwort']['Punkte'] ;
                    $id =  $maxPtL . ' ('.$minPtL.') Pt. ' . ' #' . $frageRowLinks['uid'] ;
                    $idBreite = $pdf->GetStringWidth( $id );
                    $gesBreite = $spaltenBreite - $leadWidth;
                    $pdf->Cell( $leadWidth , $H , $str  , 'B' , 0 );
                    $txt = $frageRowLinks['antwort']['minAntwort'] != $frageRowLinks['antwort']['maxAntwort'] ? $frageRowLinks['antwort']['minAntwort'] . ' bis ' .$frageRowLinks['antwort']['maxAntwort'] : $frageRowLinks['antwort']['minAntwort']; 
                    $txt .=  ' ' . $frageRowLinks['antwort']['Einheiten']; 
                    
                    $pdf->Cell( $gesBreite-$idBreite , $H , $txt , 'B' , 0 );
                    $pdf->SetFont( $pdf->pageConf['fontfamily'] , '' , round( $pdf->pageConf['fsize'] * 0.8 , 1 ) );
                    $pdf->Cell( $idBreite , $H , $id , 'B' , 0 , 'R' );
                    $pdf->SetFont( $pdf->pageConf['fontfamily'] , '' , $pdf->pageConf['fsize'] );
                    $pdf->SetX( $pdf->GetX() + $stegBreite );

                    if( $frageRechtsNr > count($frage) ) {
                        $pdf->Ln();
                    }else{
                        $str = $frageRechtsNr . ') ';
                        $leadWidth = $pdf->GetStringWidth( $str );
                        $minPtR = round( (100 - $this->settings['gewichtung_einheit_prozent']) * $frageRowRechts['antwort']['Punkte'] / 100 , 2 );
                        $maxPtR = $frageRowRechts['antwort']['Punkte'] ;
                        $id =  $maxPtR . ' ('.$minPtR.') Pt. ' . ' #' . $frageRowRechts['uid'] ;
                        $idBreite = $pdf->GetStringWidth( $id );
                        $gesBreite = $spaltenBreite - $leadWidth;
                        $pdf->Cell( $leadWidth , $H , $str , 'B' , 0 );
                        $txt = $frageRowRechts['antwort']['minAntwort'] != $frageRowRechts['antwort']['maxAntwort'] ? $frageRowRechts['antwort']['minAntwort'] . ' bis ' .$frageRowRechts['antwort']['maxAntwort'] : $frageRowRechts['antwort']['minAntwort'];
                        $txt .= ' ' . $frageRowRechts['antwort']['Einheiten']; 
                        $pdf->Cell( $gesBreite-$idBreite , $H , $txt , 'B' , 0 );
                        $pdf->SetFont( $pdf->pageConf['fontfamily'] , '' , round( $pdf->pageConf['fsize'] * 0.8 , 1 ) );
                        $pdf->Cell( $idBreite , $H , $id , 'B' , 1 , 'R' );
                        $pdf->SetFont( $pdf->pageConf['fontfamily'] , '' , $pdf->pageConf['fsize'] );
                    }
                    
                   // next 2 exercises...
            }
//             $pdf->SetDash( 0.25 , 4.75 );
            $pdf->Cell( 0 , $H / 3 * 2 , '' , '' , 1 );
            $pdf->Cell( 0 , $H / 3 , '' , '' , 1 );
//             $pdf->SetDash();
		}
		
		echo $pdf->Output( $documentname . '.pdf' , $outputType ); // D | I
		exit();
    }
}
