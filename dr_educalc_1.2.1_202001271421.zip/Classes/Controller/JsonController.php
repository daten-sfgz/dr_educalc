<?php
namespace Dr\DrEducalc\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Core\Database\ConnectionPool;


/**
 * JsonController
 */
class JsonController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

    /**
     * @var string
     */
    protected $defaultViewObjectName = 'TYPO3\CMS\Extbase\Mvc\View\JsonView';


    /**
     * Action update
     *
     * @return void
     */
    public function updateAction()
    {
		$fieldName = GeneralUtility::_GET('fieldName');
		$newValue = GeneralUtility::_GET('newValue');
		$table = GeneralUtility::_GET('table');
		$uid = GeneralUtility::_GET('uid');
		$tablename = 'tx_dreducalc_domain_model_' . strtolower($table);
		
		// execute the edit command
		$queryBuilderUpdate = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable($tablename );
		$queryBuilderUpdate->update($tablename)
			->where($queryBuilderUpdate->expr()->eq('uid', $queryBuilderUpdate->createNamedParameter($uid)))
			->set( strtolower($fieldName) , $newValue )
			->execute();
		$this->view->assign( 'value' ,  ( [ 0 => $newValue , 1 => strtolower($fieldName) ] ) );
		
		return;
		// FIXME not used anymore: verify if successed
		
		$queryBuilderSelect = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable($tablename );
		// disable 'disabled fields FIXME not used anymore, since disabled records are not editable in fe
		// $queryBuilderSelect->getRestrictions()->removeAll();
		$statement = $queryBuilderSelect->select(strtolower($fieldName))
			->from($tablename)
			->where( $queryBuilderSelect->expr()->eq('uid', $queryBuilderSelect->createNamedParameter($uid)) )
			->execute();
		// fetch the first and only row
		$row = $statement->fetch();
		// read the new value of given field
		$readedValue =  $row[strtolower($fieldName)];
		
		$this->view->assign( 'value' ,  ( [ 0 => $readedValue , 1 => strtolower($fieldName) ] ) );
    }

    /**
     * Action session
     *
     * @return void
     */
    public function sessionAction()
    {
		$this->sessionUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\SessionUtility');
		
		$fieldName = GeneralUtility::_GET('fieldName');
		$newValue = GeneralUtility::_GET('newValue');
		$table = GeneralUtility::_GET('table');
		$uid = GeneralUtility::_GET('uid');
		
		// execute the edit command
		$aData[$table][$uid] = $newValue;
		$this->sessionUtility->setData( $aData );
		
		$this->view->assign( 'value' ,  ( [ 0 => $newValue , 1 => strtolower($fieldName) , 2 => $uid , 3 => $table ] ) );
		
		return;
    }


}
