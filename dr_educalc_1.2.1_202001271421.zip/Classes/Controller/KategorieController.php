<?php
namespace Dr\DrEducalc\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Annotation as Extbase;

/***
 *
 * This file is part of the "EduCalc" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * KategorieController
 */
class KategorieController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * kategorieRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\KategorieRepository
     * @Extbase\Inject
     */
    protected $kategorieRepository = null;

    /**
     * aufgabeRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\AufgabeRepository
     */
    protected $aufgabeRepository = null;

    /**
     * constructor
     *
     * @return void
     */
    public function initializeAction()
    {
		$this->persistenceManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
		$this->datahandlerUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\DatahandlerUtility');
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$this->pages = $this->configurationManager->getContentObject()->data['pages'];
		if( !$this->pages ) $this->pages = $this->datahandlerUtility->enrichPagesWithStoragePidsFromTs( $this->pages ) ;
		if( $this->pages ) {
            $querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $querySettings->setRespectStoragePage( true );
            $querySettings->setStoragePageIds( explode(',',$this->pages) );
            $this->kategorieRepository = $objectManager->get('Dr\\DrEducalc\\Domain\\Repository\\KategorieRepository');
            $this->kategorieRepository->setDefaultQuerySettings($querySettings);
        }
        $queryAufgabeSettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
        $queryAufgabeSettings->setRespectStoragePage( false );
        $this->aufgabeRepository = $objectManager->get('Dr\\DrEducalc\\Domain\\Repository\\AufgabeRepository');
        $this->aufgabeRepository->setDefaultQuerySettings($queryAufgabeSettings);
        
		
    }

    /**
     * action list
     *
     * @param Dr\DrEducalc\Domain\Model\Kategorie
     * @return void
     */
    public function listAction()
    {
        if( $this->request->hasArgument('kategorie') && $this->request->hasArgument('sort') ) {
			$this->datahandlerUtility->moveObjectInRepository( $this->request->getArgument('kategorie') , $this->request->getArgument('sort') , $this->kategorieRepository );
		}
		$kategories = $this->kategorieRepository->findAll();
		
        $this->view->assign('kategories', $kategories);
        $this->view->assign('pages', $this->pages );
    }

    /**
     * action new
     *
     * @param Dr\DrEducalc\Domain\Model\Kategorie
     * @return void
     */
    public function newAction()
    {

    }

    /**
     * initializeCreateAction
     *
     * @return void
     */
    public function initializeCreateAction()
    {
        if( $this->request->hasArgument('abort') ) {
			$this->forward('list');
		}
    }

    /**
     * action create
     *
     * @param Dr\DrEducalc\Domain\Model\Kategorie
     * @return void
     */
    public function createAction(\Dr\DrEducalc\Domain\Model\Kategorie $newKategorie)
    {
        $this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
		
		if( $this->pages ) {
            $aPid = explode( ',' , $this->pages );
            $newKategorie->setPid( $aPid[0] );
		}
		
        $this->kategorieRepository->add($newKategorie);
        $this->redirect('list');
    }

    /**
     * action edit
     *
     * @param Dr\DrEducalc\Domain\Model\Kategorie
     * @Extbase\IgnoreValidation("Dr\DrEducalc\Domain\Model\Kategorie")
     * @return void
     */
    public function editAction(\Dr\DrEducalc\Domain\Model\Kategorie $kategorie)
    {
        $this->view->assign('kategorie', $kategorie);
        
        $aufgabes = $this->aufgabeRepository->findAllBySubtable( [$kategorie->getUid()=> 1 ] , 'aufKat' , false );
        $this->view->assign('aufgabes', $aufgabes);
        $this->view->assign('settings', $this->settings );
        
		$kategories = $this->kategorieRepository->findAll();
        $this->view->assign('kategorieliste', $kategories);
    }

    /**
     * action update
     *
     * @param Dr\DrEducalc\Domain\Model\Kategorie
     * @return void
     */
    public function updateAction(\Dr\DrEducalc\Domain\Model\Kategorie $kategorie)
    {
        $this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->kategorieRepository->update($kategorie);
        $this->redirect('list');
    }

    /**
     * action delete
     *
     * @param Dr\DrEducalc\Domain\Model\Kategorie
     * @return void
     */
    public function deleteAction(\Dr\DrEducalc\Domain\Model\Kategorie $kategorie)
    {
        $this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->kategorieRepository->remove($kategorie);
        $this->redirect('list');
    }
}
