<?php
namespace Dr\DrEducalc\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Annotation as Extbase;

/***
 *
 * This file is part of the "EduCalc" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * MaterialController
 */
class MaterialController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * materialRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\MaterialRepository
     * @Extbase\Inject
     */
    protected $materialRepository = null;

    /**
     * aufgabeRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\AufgabeRepository
     */
    protected $aufgabeRepository = null;

	/**
	 * Initializes the controller before invoking an action method.
	 *
	 * Override this method to solve tasks which all actions have in
	 * common.
	 *
	 * @return void
	 */
	protected function initializeAction() {
		$this->persistenceManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
		$this->datahandlerUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\DatahandlerUtility');
 		
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$this->pages = $this->configurationManager->getContentObject()->data['pages'];
		if( !$this->pages ) $this->pages = $this->datahandlerUtility->enrichPagesWithStoragePidsFromTs( $this->pages ) ;
		if( $this->pages ) {
            $querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $querySettings->setRespectStoragePage( true );
            $querySettings->setStoragePageIds( explode(',',$this->pages) );
            $this->materialRepository = $objectManager->get('Dr\\DrEducalc\\Domain\\Repository\\MaterialRepository');
            $this->materialRepository->setDefaultQuerySettings($querySettings);
        }
        $queryAufgabeSettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
        $queryAufgabeSettings->setRespectStoragePage( false );
        $this->aufgabeRepository = $objectManager->get('Dr\\DrEducalc\\Domain\\Repository\\AufgabeRepository');
        $this->aufgabeRepository->setDefaultQuerySettings($queryAufgabeSettings);
		
	}

    /**
     * action list
     *
     * @param Dr\DrEducalc\Domain\Model\Material
     * @return void
     */
    public function listAction()
    {
        if( $this->request->hasArgument('material') && $this->request->hasArgument('sort') ) {
			$this->datahandlerUtility->moveObjectInRepository( $this->request->getArgument('material') , $this->request->getArgument('sort') , $this->materialRepository );
		}
		
		$materials = $this->materialRepository->findAll();
		
        $this->view->assign('materials', $materials);
        $this->view->assign('pages', $this->pages );
    }

    /**
     * action new
     *
     * @param Dr\DrEducalc\Domain\Model\Material
     * @return void
     */
    public function newAction()
    {

    }

    /**
     * initializeCreateAction
     *
     * @return void
     */
    public function initializeCreateAction()
    {
        if( $this->request->hasArgument('abort') ) {
			$this->forward('list');
		}
    }

    /**
     * action create
     *
     * @param Dr\DrEducalc\Domain\Model\Material
     * @return void
     */
    public function createAction(\Dr\DrEducalc\Domain\Model\Material $newMaterial)
    {
        $this->addFlashMessage('Die neue Tabelle wurde erstellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
		
		if( $this->pages ) {
            $aPid = explode( ',' , $this->pages );
            $newMaterial->setPid( $aPid[0] );
		}
		
        $this->materialRepository->add($newMaterial);
		$persistenceManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
		$persistenceManager->persistAll();
		
		$this->redirect('edit',null,null,array('material' => $newMaterial));
    }

	/**
	 * duplicateAction
	 *
     * @param Dr\DrEducalc\Domain\Model\Material
	 * @return void
	 */
	public function duplicateAction(\Dr\DrEducalc\Domain\Model\Material $material) {
            $newMaterial = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Dr\DrEducalc\Domain\Model\Material');
            
            $properties = $material->_getProperties();
            
            $oldUid = $properties['uid'];
            unset($properties['uid']) ;

            $properties['tabellenname'] = 'K' . $oldUid . ' ' . $properties['tabellenname'];
            $properties['crdate'] = time();
            $properties['timestamp'] = time();

            foreach ($properties as $key => $value ) $newMaterial->_setProperty( $key , $value );
            $this->materialRepository->add( $newMaterial );
            $this->persistenceManager->persistAll();
            $this->addFlashMessage('Das Material #' . $oldUid . ' wurde dupliziert zu #'.$newMaterial->getUid().'.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            
			$this->forward( 'edit' , null , null , [ 'material' => $newMaterial ] );
	}

    /**
     * action edit
     *
     * @Extbase\IgnoreValidation("material")
     * @param Dr\DrEducalc\Domain\Model\Material
     * @return void
     */
    public function editAction(\Dr\DrEducalc\Domain\Model\Material $material)
    {
        $this->view->assign('material', $material);
        
        $aufgabes = $this->aufgabeRepository->findAllBySubtable( [ $material->getUid() => 1 ] , 'aufMat' );
        $this->view->assign('aufgabes', $aufgabes);
        $this->view->assign('settings', $this->settings );
        
		$materials = $this->materialRepository->findAll();
        $this->view->assign('materialliste', $materials);
    }

    /**
     * initializeUpdateAction
     *
     * @return void
     */
    public function initializeUpdateAction()
    {
        if( $this->request->hasArgument('abort') ) {
			$this->forward('list');
		}
    }

    /**
     * action update
     *
     * @param Dr\DrEducalc\Domain\Model\Material
     * @return void
     */
    public function updateAction(\Dr\DrEducalc\Domain\Model\Material $material)
    {
        if( $this->request->hasArgument('delete') ) {
			$this->forward('delete' , null , null , [ 'material' => $material ] );
		}
        if( $this->request->hasArgument('dupliz') ) {
			$this->redirect('duplicate' , null , null , [ 'material' => $material ] );
		}
		
        $this->addFlashMessage('Die Tabelle »' . $material->getUid() . '« wurde gespeichert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        $this->materialRepository->update($material);
        
        if( $this->request->hasArgument('okclose') ) {
			$this->redirect('list');
		}
		$this->redirect('edit' , null , null , [ 'material' => $material ] );
    }

    /**
     * action delete
     *
     * @param Dr\DrEducalc\Domain\Model\Material
     * @return void
     */
    public function deleteAction(\Dr\DrEducalc\Domain\Model\Material $material)
    {
        $this->addFlashMessage('Die Tabelle »' . $material->getUid() . '« wurde gelöscht.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->materialRepository->remove($material);
        $this->redirect('list');
    }

    /**
     * action fancytable
     * all parameters are optional
     * 
	 * @param \Dr\DrEducalc\Domain\Model\Material $material
	 * @param integer $auflage_von
	 * @param integer $auflage_bis
	 * @param integer $auflage_itr
	 * @param string $prozent_von
	 * @param string $prozent_bis
	 * @param string $prozent_itr
	 * @param integer $abnahme
	 * @param string $nachkomma_von
	 * @param string $nachkomma_bis
	 * @param integer $nachkomma_stelle
	 * @param integer $expert
     * @return void
     */
    public function fancytableAction(\Dr\DrEducalc\Domain\Model\Material $material = NULL,
					  $auflage_von=1000,
					  $auflage_bis=1200,
					  $auflage_itr=100,
					  $prozent_von=1.4,
					  $prozent_bis=2.3,
					  $prozent_itr=0.1,
					  $abnahme=0,
					  $nachkomma_von=0,
					  $nachkomma_bis=4,
					  $nachkomma_stelle=0,
					  $expert=0
	)
    {
		$nachkommas_stellen = array( 1,2,3,4,5 );
		
		if( empty($auflage_itr) || trim($auflage_itr) == '' ) $auflage_itr = 100;
		if( empty($prozent_itr) || trim($prozent_itr) == '' ) $prozent_itr = 0.1;
		
		$this->view->assign('material', $material);
		
		$aDruckbogen = [];
		$aAuflagen = [];
		
		if( $auflage_bis < $auflage_von ) $auflage_bis += $auflage_von;
		
		if( $expert ){
			$aNachkommasAb =array( 0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9 );
			$aNachkommasZu =array(   0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1 );
		}elseif( $abnahme ){
			$aNachkommasAb =array( 0,0.1,0.2,0.3,0.4 );
			$aNachkommasZu =array(   0.1,0.2,0.3,0.4,0.5 );
		}else{
			$aNachkommasAb =array( 0.5,0.6,0.7,0.8,0.9 );
			$aNachkommasZu =array(   0.6,0.7,0.8,0.9,1 );
		}
		
		$diffBetween = $nachkomma_bis - $nachkomma_von;
		if( !$nachkomma_stelle && $diffBetween < 1 ) {
				if( !$nachkomma_von ){ // 'greaterThan' is on min 
					$nachkomma_bis = 1;
				}else{
					if( $nachkomma_von == count($aNachkommasAb)-1 ) {
						$nachkomma_von -=1; // 'greaterThan' is on max
					}
					$nachkomma_bis = $nachkomma_von + 1;
				}
		}elseif( $diffBetween < 0 ) {
				$nachkomma_bis = $nachkomma_von;
		}
		
		$this->view->assign('auflage_von', $auflage_von);
		$this->view->assign('auflage_bis', $auflage_bis);
		$this->view->assign('auflage_itr', $auflage_itr);
		$this->view->assign('prozent_von', $prozent_von);
		$this->view->assign('prozent_bis', $prozent_bis);
		$this->view->assign('prozent_itr', $prozent_itr);
		$this->view->assign('abnahme', $abnahme);
		
		$this->view->assign('nachkomma_von', $nachkomma_von);
		$this->view->assign('nachkomma_bis', $nachkomma_bis);
		$this->view->assign('nachkomma_stelle', $nachkomma_stelle);
		$this->view->assign('expert', $expert);
		
		$this->view->assign('nachkommas_ab', $aNachkommasAb );
		$this->view->assign('nachkommas_zu', $aNachkommasZu );
		$this->view->assign('nachkommas_stellen', $nachkommas_stellen );
		
		$diffMin = $aNachkommasAb[ $nachkomma_von ];
		$diffMax = $aNachkommasZu[ $nachkomma_bis ];
		$dezimalStellen = $nachkommas_stellen[ $nachkomma_stelle ];

		// $abnahme = 0 zunahme ab Auflage: zielwert (Lieferung) nicht ueberschreiten
		// $abnahme = 1 abnahme ab Druckbogen: zielwert (Auflage) nicht unterschreiten
		for( $prozentsatz = $prozent_von; $prozentsatz <= $prozent_bis ; $prozentsatz +=$prozent_itr ){
				$zuschussprozent = $abnahme ? 100 : 100 + $prozentsatz;
				$ausschussprozent = $abnahme ? 100 - $prozentsatz : 100;
				for($auflage = $auflage_von; $auflage <= $auflage_bis ; $auflage+=$auflage_itr ) {
						$druckbogen = $auflage / $ausschussprozent *  $zuschussprozent ;
						$diff =  round( $druckbogen - floor($druckbogen) , $dezimalStellen ) ;
						if( $diff > $diffMin && $diff < $diffMax) {
								$aDruckbogen[10*$prozentsatz][$auflage] = $druckbogen;
						}
				}
		}
		
		// basis , percentage , result
		if( $abnahme ){
			$basis = 'result';
			$result = 'basis';
		}else{
			$basis = 'basis';
			$result = 'result';
		}
		
		if( count($aDruckbogen) ){
		    foreach( $aDruckbogen as $prz => $grp ){
				foreach( $grp as $aufl => $druckbogen ){
					$uid = sprintf('%012s',$aufl).'_'.sprintf('%02s',$prz);
					$aAuflagen[ $uid ]=array( $basis=>$aufl , $result=>round( $druckbogen , $dezimalStellen ) , 'percentage'=>$prz/10 );
				}
		    }
		}
		if( count($aAuflagen) ) ksort($aAuflagen);
		
		$this->view->assign('druckbogen', $aAuflagen );
		
		$this->fancytable_addJs();

    }

    /**
     * fancytable_addJs
     * 
     * @return void
     */
    public function fancytable_addJs()
    {
// 		$GLOBALS['TSFE']->additionalHeaderData['dr_educalc_clipboard'] = '<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.7.1/clipboard.min.js" type="text/javascript"></script>';
		$GLOBALS['TSFE']->additionalHeaderData['educalc_clipboard'] = '<script src="typo3conf/ext/sfgz_fetools/Resources/Public/Scr/clipboard.min.js" type="text/javascript"></script>';
		
		$jscode = "$(document).ready(
			function(){
				var clipboard = new Clipboard('.copy-button'); 
				clipboard.on('success', function(e) {
					alert('Die Tabelle wurde in die \\nZwischenablage kopiert.');
				});
			}\n);";
		$GLOBALS['TSFE']->setJS('educalc_clipboard', $jscode );
    }
}
