<?php
namespace Dr\DrEducalc\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "EduCalc" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * MigrationController
 */
class MigrationController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * info
     *
     * @var array
     */
    Public $info = array();

    /**
     * cloneDB
     *
     * @var array
     */
    Protected $cloneDB = array();
    
    /**
     * fieldMap
     *
     * @var array
     */
    Protected $fieldMap = [
                'foreignDb' => [
                    'tables' => [ 'auf' => 'exercise' , 'cat' => 'category' , 'mat' => 'material' ],
                    'sorting' => 'sort',
                    'extensionName' => 'tx_dreducalc_',
                    'modelBasename' => 'tx_dreducalc_domain_model_'
                ] ,
                'convert' => [
                    'in' => 'utf-8',
                    'out' => 'ISO-8859-15'
                ] ,
                'ingredients' => [
                    'targetDb' => [
                            'host' => 'daten.verarbeitung.ch',
                            'dbname' => 'wirker_daten',
                            'user' => 'wirker_daru',
                            'password' => '1gdrasil',
                            'charset' => 'utf8mb4',
                            'driver' => 'mysqli'
                    ] ,
                    'sourceDb' => [
                            'host' => 'daten.verarbeitung.ch',
                            'dbname' => 'wirker_t3b',
                            'user' => 'wirker_daru',
                            'password' => '1gdrasil',
                            'charset' => 'utf8mb4',
                            'driver' => 'mysqli'
                    ]
                ] ,
                'modelBasename' => 'tx_dreducalc_domain_model_',
                'auf' => [
                        'foreignUid' => '65',
                        'tablename' => 'aufgabe',
                        'mmTables' => [ 'cat' => 'tx_dreducalc_aufgabe_kategorie_mm' , 'mat' => 'tx_dreducalc_aufgabe_material_mm' ] ,
                        'replacements' => [
                                'formeln' => [ '#' => '$' ] ,
                                'aufgabe' => [ '#' => '$' ] ,
                                'hilfetext' => [ '#' => '$' ] 
                        ],
                        'fields' => [
                                'titel' => 'titel',
                                'aufgabe' => 'aufgabe',
                                'antwort' => 'antwort',
                                'toleranzwert' => 'toleranzwert',
                                'toleranzmin' => 'toleranzmin',
                                'toleranzmax' => 'toleranzmax',
                                'einheiten' => 'einheiten',
                                'zeitvorgabe' => 'zeitvorgabe',
                                'formeln' => 'formeln',
                                'hilfetext' => 'hilfetext',
                                'gruppe' => 'sort'
                        ]
                ] ,
                'cat' => [
                        'foreignUid' => '16',
                        'tablename' => 'kategorie',
                        'fields' => [
                                'kategorie' => 'category',
                                'sorting' => 'sort'
                        ]
                ] ,
                'mat' => [
                        'foreignUid' => '15',
                        'tablename' => 'material',
                        'fields' => [
                            'tabellenname' => 'tabellenname',
                            'felder' => 'felder',
                            'tabelle' => 'tabelle'
                        ]
                ]
            ];

    /**
     * page
     *
     * @var int
     */
    Protected $page = null;
    
    /**
     * constructor
     *
     * @return void
     */
    public function initializeAction()
    {
// 			$this->extConf = GeneralUtility::makeInstance(
// 				\TYPO3\CMS\Core\Configuration\ExtensionConfiguration::class
// 			)->get('dr_educalc');
            $objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
            $this->configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
            $page = $this->configurationManager->getContentObject()->data['pages'];
            if( !$page ) {
                    $this->datahandlerUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\DatahandlerUtility');
                    $page = $this->datahandlerUtility->enrichPagesWithStoragePidsFromTs( $page ) ;
            }
            $aPg = explode( ',' , $page );
            $this->page = $aPg[0];
    }

    /**
     * action migrate
     * 
     * - detect kategories and materials of each folder
     * - build folder, 
     * - create kategorie and materials, 
     * - create aufgabes and insert reations to mm tables for aufKat and aufMat
     *
     * @return void
     */
    public function migrateAction()
    {

            $this->connectToDatabase( 'sourceDb' );
            $this->cloneDB['pages'] = $this->readForeignDB();
            $this->closeDatabase();
            
            if( $this->request->hasArgument('db') ) {
                $inDb = $this->request->getArgument('db');
                if( $inDb['ok'] ) {
                    $this->connectToDatabase( 'targetDb' );
                    $this->cloneDB['message'] = $this->copyDBtoLocal();
                    $this->closeDatabase();
                }
            }
            
            $this->view->assign( 'db' , $this->cloneDB );
            
            $this->view->assign( 'page' , $this->page );
            
    }
	
	/**
	 * copyDBtoLocal
	 * 
	 * @return array 
	 */
    Protected function copyDBtoLocal()
    {
                // create page, get new uid and change the uid in clone's pageUid in clone.[pid].pageUid
                // create kategorie with this pid and change the clone's catUid in clone.[pid].cat.[uid].catUid
                // create material with this pid and change the clone's matUid in clone.[pid].mat.[uid].matUid [ tabellenname , felder , tabelle ]
                // create aufgabe  with this pid and insert records in mm-tables for given materials and kategories
                
                $z = 0;
                foreach( $this->cloneDB['pages'] as $foreignPid => $pageRow ){
                        // add page
                        $properties = [ 'title' => $pageRow['title'] , 'pid' => $this->page ];
                        $this->cloneDB['pages'][$foreignPid]['pageUid'] = $this->addPage( $properties );
                        
                        // add categories
                        $this->copy_tables( $foreignPid , 'cat' );
                        $z += count( $this->cloneDB['pages'][$foreignPid]['cat']);
                        
                        // add materials
                        $this->copy_tables( $foreignPid , 'mat' );
                        $z += count( $this->cloneDB['pages'][$foreignPid]['mat']);
                        
                        // add execises
                        $this->copy_tables( $foreignPid , 'auf' );
                        $z += count( $this->cloneDB['pages'][$foreignPid]['auf']);
                        
                }
                return '' . count($this->cloneDB['pages']) . ' Seiten kopiert, ' . $z . ' Datensaetze erstellt. ' . date( 'd.m.y, H:i:s' ) . '. ';
                
    }
	
	/**
	 * copy_tables
	 * 
	 * @return array 
	 */
    Protected function copy_tables( $foreignPid , $short )
    {
            foreach( $this->cloneDB['pages'][$foreignPid][$short] as $foreignUid => $tabRow ){
                
                    $properties = [];
                    foreach( $this->fieldMap[$short]['fields'] as $fldNew => $fldOld ) {
                        $value = isset($this->fieldMap[$short]['replacements'][$fldNew]) ? str_replace( array_keys($this->fieldMap[$short]['replacements'][$fldNew]) , $this->fieldMap[$short]['replacements'][$fldNew] , $tabRow['cnt'][$fldOld] ) : $tabRow['cnt'][$fldOld];
                        $properties[$fldNew] = $this->convertIf( $value );
                    }
                    $properties['pid'] = $this->cloneDB['pages'][$foreignPid]['pageUid'];
                    $this->cloneDB['pages'][$foreignPid][$short][$foreignUid][ $short . 'Uid'] = $this->addRecord( $this->fieldMap['modelBasename'] . $this->fieldMap[$short]['tablename'] , $properties );
                    
                    if( isset($this->fieldMap[$short]['mmTables']) ) {
                        foreach( array_keys( $this->fieldMap[$short]['mmTables'] ) as $mmShort ) $this->copy_mmTables( $foreignPid , $short , $foreignUid , $mmShort );
                    }
            }
            
            return count( $this->cloneDB['pages'][$foreignPid][$short]);
    }
	
	/**
	 * copy_mmTables
	 * 
	 * @return array 
	 */
    Protected function copy_mmTables( $foreignPid , $short , $foreignUid , $mmShort )
    {
            foreach( $this->cloneDB['pages'][$foreignPid][$short][$foreignUid][ $short . ucFirst($mmShort) ] as $subUid ){
                    $newIx = $this->cloneDB['pages'][$foreignPid][$mmShort][$subUid][ $mmShort . 'Uid' ];
                    $properties = [ 'uid_local'=> $this->cloneDB['pages'][$foreignPid][$short][$foreignUid][ $short . 'Uid' ] , 'uid_foreign' => $newIx ];
                    $this->insertRecordFromArray( $this->fieldMap[$short]['mmTables'][$mmShort]  , $properties );
            }
    }
	
	/**
	 * convertIf
	 * 
	 * @param str $value
	 * @return int
	 */
    Protected function convertIf( $value )
    {
         if( $this->fieldMap['convert']['in'] == $this->fieldMap['convert']['out'] ) return $value;
         return is_integer($value) || is_long($value) || is_bool($value) ? $value : iconv( $this->fieldMap['convert']['in'] , $this->fieldMap['convert']['out'] , $value );
    }
	
	/**
	 * addPage
	 *  Creates a page with type 'folder' under a given pid or 0.
	 *  If title is empty, it inserts the new uid.
	 *  Returns the new page uid.
	 * 
	 * @param array $properties
	 * @return int
	 */
    Protected function addPage( $properties )
    {
        $preset['pid'] = $properties['pid'];
        $preset['title'] = $properties['title'];
        
        $preset['doktype'] = 254; // folder
        $preset['perms_userid'] = 1; // owner admin
        $preset['perms_groupid'] = 1; // group 1 (eg. teachers)
        $preset['perms_user'] = 31; // all grants by user
        $preset['perms_group'] = 27; // all grants by group
        
        $newUid = $this->addRecord( 'pages' , $preset );
        
        if( empty($preset['title']) ) $this->execQuery( 'UPDATE pages SET  title="' . $newUid . '"  WHERE uid=' . $newUid . ';' );
        
        return $newUid;
        
    }
	
	/**
	 * addRecord
	 *  Creates a record
	 *  Returns the new record uid.
	 * 
	 * @param string $tablename like tx_dreducalc_domain_model_aufgabe or tx_dreducalc_aufgabe_kategorie_mm
	 * @param array $properties
	 * @return int
	 */
    Protected function addRecord( $tablename , $properties )
    {
        $properties['cruser_id'] = 1; // creator admin
        $properties['crdate'] = time();
        $properties['tstamp'] = time();
        
        return $this->insertRecordFromArray( $tablename , $properties );
    }
	
	/**
	 * insertRecordFromArray
	 * 
	 * @param string $tablename like tx_dreducalc_domain_model_aufgabe or tx_dreducalc_aufgabe_kategorie_mm
	 * @param array $properties
	 * @return int
	 */
    Protected function insertRecordFromArray( $tablename , $properties )
    {
        $sql = 'INSERT INTO ' . $tablename . ' (' . implode( ',' , array_keys($properties) ) . ')';
        $sql.= ' VALUES ("' . implode( '","' , $properties ) . '");' ;
        
        $this->execQuery( $sql );
        
        $aResult = $this->runQuery( 'SELECT MAX(uid) AS lastUid FROM ' . $tablename . ';');
        $first = reset($aResult);
        
        return $first['lastUid'];
    }
	
	/**
	 * readForeignDB
	 *  if pid exists this will 
	 *  remap all tables with new relations. contains no data, only uids
	 * 
	 * @return array 
	 */
    Protected function readForeignDB()
    {
                $dbMapping = [];
                $auf = $this->fieldMap['foreignDb']['tables']['auf'];
                $srt = $this->fieldMap['foreignDb']['sorting'];
                $modelAuf = $this->fieldMap['foreignDb']['modelBasename'] . $auf;
                
                // create the page tree and
                // assign exercises to 'auf'
                $sql =  "SELECT " . $modelAuf . ".*, pages.title " ;
                $sql .= "FROM " . $modelAuf . " " ;
                $sql .= "JOIN pages ON " . $modelAuf . ".pid = pages.uid " ;
                $sql .= "WHERE " . $modelAuf . ".antwort > '' " ;
                $sql .= "AND " . $modelAuf . ".deleted = 0 " ;
                $sql .= "ORDER BY " . $modelAuf . ".pid," . $modelAuf . "." . $srt . ";" ;
                $dbExercise = $this->runQuery( $sql );
                // set uid as indes
                foreach( $dbExercise as $row ){
                        $dbMapping[ $row['pid'] ]['title'] = $row['title'];
                        $dbMapping[ $row['pid'] ]['pageUid'] = $row['pid'];
                        $dbMapping[ $row['pid'] ]['auf'][ $row['uid'] ]['aufUid'] = $row['uid'];
                        $dbMapping[ $row['pid'] ]['auf'][ $row['uid'] ]['cnt'] = $row;
                }
                
                // map subtables and assign to cat or mat
                $namesList = [ 'cat' , 'mat' ];
                foreach( $namesList as $short ) {
                        $tablename = $this->fieldMap['foreignDb']['tables'][$short];
                        $modelSub = $this->fieldMap['foreignDb']['modelBasename'] . $tablename;
                        $mmTable = $this->fieldMap['foreignDb']['extensionName'] . $auf . '_' . $tablename . '_mm';

                        // collect as array to map later the uids as index
                        $aMapUids = [];
                        $table = $this->runQuery( 'SELECT * FROM ' . $modelSub . ';' );
                        foreach( $table as $ix => $row ) $aMapUids[ $row['uid'] ] = $row;
                        // create query for mm-table
                        $sql =  'SELECT ' . $modelAuf . '.uid , ' ;
                        $sql .= $modelAuf . '.pid , ' ;
                        $sql .= $modelSub . '.uid AS ' . $short . 'Uid ' ;
                        $sql .= 'FROM ' . $modelAuf . ' ' ;
                        $sql .= 'JOIN ' . $mmTable . ' ON ' . $modelAuf . '.uid = ' . $mmTable . '.uid_local ' ;
                        $sql .= 'JOIN ' . $modelSub . ' ON ' . $modelSub . '.uid = ' . $mmTable . '.uid_foreign ' ;
                        $sql .= 'WHERE ' . $modelSub . '.deleted = 0 ' ;
                        $sql .= 'AND ' . $modelAuf . '.deleted = 0 ' ;
                        $sql .= 'ORDER BY ' . $modelAuf . '.pid,' . $modelAuf . '.' . $srt . ' ;' ;
                        
                        $dbCat = $this->runQuery( $sql );
                        // set uid as indes
                        foreach( $dbCat as $row ){
                                $uidAlias = $short . 'Uid';
                                $dbMapping[ $row['pid'] ]['auf'][ $row['uid'] ]['auf' . ucFirst($short) ][ $row[$uidAlias] ] = $row[$uidAlias];
                                $dbMapping[ $row['pid'] ][$short][ $row[$uidAlias] ][$uidAlias] = $row[$uidAlias] ;
                                $dbMapping[ $row['pid'] ][$short][ $row[$uidAlias] ]['cnt'] = $aMapUids[ $row[$uidAlias] ];
                        }
                }
                
                return $dbMapping;
    }

	/**
	 * connectToDatabase
	 * 
	 * @param string $dbKey
	 * @return array 
	 */
	Protected function connectToDatabase( $dbKey )
	{
		$dbname = $this->fieldMap['ingredients'][$dbKey]['dbname'];
		/* check ingredients */
	    if( empty($dbname) ) {
			$this->info['error'][] = 'no dbname given';
			
	    }else{
			$i = $this->fieldMap['ingredients'][$dbKey];
			if( !is_array($i) ) {
				$this->info['error'][] = 'no ingredients given for db "'.$dbname.'".';
				
			}else{
				foreach( $i as $nam => $cont ) {
					if( empty( $cont ) ) $this->info['error'][] = 'no '.$nam.' given for db "'.$dbname.'".';
				}
			}
	    }
		if( isset($this->info['error']) && count($this->info['error']) ) return false;
	    
		/* try to connect */
		$this->connection = @mysqli_connect( $i['host'] , $i['user'] , $i['password'] , $dbname );

		/* check connection */
		if( !$this->connection ){
			$this->info['error'][] = ' Connection failed(host:' .  $i['host'] . ',user:' .  $i['user'] . ',db:' .  $dbname . ') ' ;
		
		}elseif ( $this->connection->connect_errno ) {
			$this->info['error'][] = sprintf("Connect failed: %s\n", $this->connection->connect_error);
			$this->connection = false;
		
		}
		if( isset($this->info['error']) && count($this->info['error']) ) return false;
		
		return true;
	}
	
	/**
	 * closeDatabase
	 * 
	 * @return void 
	 */
	Protected function closeDatabase()
	{
		if( $this->connection ) $this->connection->close();
		$this->connection = false;
	}
	
	
	/**
	 * execQuery
	 * @param string $query
	 * @return boolean 
	 */
	Protected function execQuery( $query )
	{
	    if( empty( $query ) ) return false;
	    if( !$this->connection ) return false;
		$result = $this->connection->query( $query );
		return $result;
	}
	
	/**
	 * runQuery
	 * @param string $query
	 * @return array 
	 */
	Protected function runQuery( $query )
	{
	    $aQueryResult = [];
	    if( empty( $query ) ) return $aQueryResult;
		if ( $this->connection && $result = $this->connection->query( $query ) ) {
			$z=1;
			while ($row = $result->fetch_assoc()) {
				foreach($row as $fld => $cnt ) $aQueryResult[$z][$fld] = utf8_encode($cnt);
				$z+=1;
			}
			$result->free();
		}
	    return $aQueryResult;
	}
    
} 
