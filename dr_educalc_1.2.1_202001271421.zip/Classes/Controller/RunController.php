<?php
namespace Dr\DrEducalc\Controller;

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Annotation as Extbase;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility ;

/***
 *
 * This file is part of the "EduCalc" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * RunController
 */
class RunController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * aufgabeRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\AufgabeRepository
     * @Extbase\Inject
     */
    protected $aufgabeRepository = null;

    /**
     * execiseUtility
     *
     * @var \Dr\DrEducalc\Utility\ExeciseUtility
     */
    protected $execiseUtility = null;

    /**
     * constructor
     *
     * @return void
     */
    public function initializeAction()
    {
		$this->execiseUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\ExeciseUtility');
		$this->datahandlerUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\DatahandlerUtility');
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		$this->sessionUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\SessionUtility');
		
		$this->configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$this->pages = $this->configurationManager->getContentObject()->data['pages'];
		if( !$this->pages ) $this->pages = $this->datahandlerUtility->enrichPagesWithStoragePidsFromTs( $this->pages ) ;
		
		if( $this->pages ) {
            $querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $querySettings->setRespectStoragePage( true );
            $querySettings->setStoragePageIds( explode(',',$this->pages) );
            $this->aufgabeRepository = $objectManager->get('Dr\\DrEducalc\\Domain\\Repository\\AufgabeRepository');
            $this->aufgabeRepository->setDefaultQuerySettings($querySettings);
        }
    }

    /**
     * action tryal
     *
     * @return void
     */
    public function tryalAction()
    {
        if( $this->request->hasArgument('pdf') ) {
			$this->redirect('exam');
        }elseif( $this->request->hasArgument('exam') ) {
			$this->redirect('exam');
        }
		
 		$aExames = $this->aufgabeRepository->findByPidAndNotVersteckt( $this->pages );
//        $sessFilter = $this->sessionUtility->getData(  );
//		$sessFilter = $this->datahandlerUtility->getFilterItemsByPids( $sessFilter , $this->pages ) ;
        $sessFilter = $this->datahandlerUtility->getSessDataForPids( 'kategorie' , $this->pages );
        $aFltExames = $this->aufgabeRepository->findNotVerstecktInPidBySubtable( $sessFilter , 'aufKat' , $this->pages , 'OR' );
        
        $aCalcs = $this->execiseUtility->getExamesList( $aFltExames , [ 'amount'=>1 , 'grouped'=>0 ] );
        $aAufgabes = current($aCalcs);
        
		$aFlt = $this->datahandlerUtility->getUsedKategorienFilter( $aExames ) ;
        $this->view->assign('filter', $aFlt );
        
        $this->view->assign('aExercises', $aAufgabes );
        $this->view->assign('sessFilter', $sessFilter );
        $this->view->assign('pages', $this->pages );
        
    }

    /**
     * action exam
     *
     * @return void
     */
    public function examAction()
    {
		
 		$aExames = $this->aufgabeRepository->findByPidAndNotVersteckt( $this->pages );

        $sessFilter = $this->datahandlerUtility->getSessDataForPids( 'kategorie' , $this->pages );
        $aFltExames = $this->aufgabeRepository->findNotVerstecktInPidBySubtable( $sessFilter , 'aufKat' , $this->pages, 'OR' );
        $aCalcs = $this->execiseUtility->getExamesList( $aFltExames , [ 'amount'=>1 , 'grouped'=>1 ] );
        $aAufgabes = current($aCalcs);
        
		$aFlt = $this->datahandlerUtility->getUsedKategorienFilter( $aExames ) ;
        $this->view->assign('filter', $aFlt );
        
        $this->view->assign('aufgabes', $aAufgabes );

        $aCompressedExames = $this->execiseUtility->compressExame( $aAufgabes );
        $this->view->assign('aCompressedExames', $aCompressedExames );

    }

    /**
     * initializeResultAction
     *
     * @return void
     */
    public function initializeResultAction()
    {
        if( $this->request->hasArgument('tryal') ) {
			$this->redirect('tryal');
        }elseif( $this->request->hasArgument('exam') ) {
			$this->redirect('exam');
        }
    }

    /**
     * action result
     *
     * @param array $aAufgabes
     * @return void
     */
    public function resultAction( $aAufgabes )
    {
        $aExames = $this->execiseUtility->decompressExamesList( $aAufgabes );
        $this->view->assign('aJsonAufgabes', json_encode( $aExames ) );

        $aResult = $this->execiseUtility->calculateResults( $aExames , $this->settings );
        $this->view->assign('aResult', $aResult );

    }

    /**
     * initializeCertifyAction
     *
     * @return void
     */
    public function initializeCertifyAction()
    {
        if( $this->request->hasArgument('tryal') ) {
			$this->redirect('tryal');
        }elseif( $this->request->hasArgument('exam') ) {
			$this->redirect('exam');
        }
    }

    /**
     * action certify
     *
     * @param array $aJsonAufgabes
     * @return void
     */
    public function certifyAction( $aJsonAufgabes )
    {
	    $aAufgabes = json_decode( $aJsonAufgabes['aAufgabes'] , true );
	    
	    // calculate
	    $aResult = $this->execiseUtility->calculateResults( $aAufgabes , $this->settings );
	    
	    $docuname = 'pruefung_' . date( 'Ymd_Hi' );
	    
	    $this->pdfUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\PdfUtility');

	    $LlTitle = $this->pdfUtility->llEncode( 'title_result' );

		$this->pdfUtility->initializePdf([ 
                'title' =>  $LlTitle , 
                'subject' =>  $docuname . '.pdf' , 
                'imagePath' => GeneralUtility::getFileAbsFileName( $this->settings['logo_pfad'] ) , 
                'leftMargin' => 35.5 
        ]);
		
		$pageConf = $this->pdfUtility->pageConf;
		$lh = $pageConf['lfeed'];
		
        $this->pdfUtility->StartPageGroup();
		$this->pdfUtility->AddPage();
		$this->pdfUtility->mkTitle( $LlTitle );
		
        $str = $this->pdfUtility->llEncode( 'date' ) . ': ' . date( 'd.m.Y\, H:i:s \U\h\r' ) ;
		$this->pdfUtility->Cell( 0 , $lh , $str , '' , 1 );
		
        $str = $this->pdfUtility->llEncode( 'name' ) . ': ';
		$this->pdfUtility->Cell( $this->pdfUtility->GetStringWidth( $str ) , $lh , $str , '' , 0 );
		
        $str = $this->pdfUtility->encode( $aResult['sum']['name'] );
        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , 'B' , $pageConf['fsize'] );
		$this->pdfUtility->Cell( 0 , $lh , $str , '' , 1 );
        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , '' , $pageConf['fsize'] );

  	    $line = LocalizationUtility::translate('tx_dreducalc.exam.endgrade','dr_educalc') . ': <b>' . round( $aResult['sum']['endNote'] , 1 ) . '</b>';
  	    if( round( $aResult['sum']['endNote'] , 1 ) != $aResult['sum']['endNote'] ) $line .= ' (' .  LocalizationUtility::translate('tx_dreducalc.exam.unrounded','dr_educalc') . ' ' . $aResult['sum']['endNote'] . ')';
  	    $line .= '.';
        $this->pdfUtility->WriteHTML(  $this->pdfUtility->localchars( $line )  );
        $this->pdfUtility->Ln();
        
        $this->pdfUtility->Cell( 0 , $lh , $this->pdfUtility->llEncode( 'reached.points' , [$aResult['sum']['erreichtePunkte'],$aResult['sum']['maximalPunkte']] ) . '. ' , '' , 1 );
        
		$encStr = $this->pdfUtility->llEncode( 'reached.times' , [$aResult['sum']['istZeit'],$aResult['sum']['sollZeit']] ) . '. ';
        $this->pdfUtility->Cell( $this->pdfUtility->GetStringWidth( $encStr ) , $lh , $encStr , '' , 0 );
	    
        if( $aResult['sum']['abzugZeitNote'] ) {
            $this->pdfUtility->Ln();
            $line = '<b>' . LocalizationUtility::translate('tx_dreducalc.exam.assessment.grade_subtract','dr_educalc' , [ $aResult['sum']['abzugZeitNote'] ] )  . '</b> ';
            $line .= LocalizationUtility::translate('tx_dreducalc.exam.assessment.subtract_from_grade','dr_educalc' , [ $aResult['sum']['punkteNote'] ] )  . ', ' ;
            $line .= LocalizationUtility::translate('tx_dreducalc.exam.timehint.overdued','dr_educalc' , [ $aResult['sum']['mehrZeitProzent'] ] );
            $this->pdfUtility->WriteHTML(  $this->pdfUtility->localchars( $line )  );
            $this->pdfUtility->Ln();
        }else{
            if( empty($this->settings['zeitabzug_maximalprozent']) ) {
                $line = LocalizationUtility::translate('tx_dreducalc.exam.timehint.disabled','dr_educalc') . '.';
            }elseif( $aResult['sum']['istZeit'] > $aResult['sum']['sollZeit']  ){
                $line = LocalizationUtility::translate('tx_dreducalc.exam.timehint.no_subtraction','dr_educalc') . '.';
            }else{
                $line = LocalizationUtility::translate('tx_dreducalc.exam.timehint.reached','dr_educalc') . '.';
            }
            $this->pdfUtility->Cell( 0 , $lh , $this->pdfUtility->encode($line) , '' , 1 );
        }

        $y = $this->pdfUtility->GetY() + $lh / 4;
        $this->pdfUtility->Line( $pageConf['leftMargin'] , $y , 210 - $pageConf['rightMargin'] , $y );
		
		if( isset($aResult['data']) && is_array($aResult['data']) ){
                foreach($aResult['data'] as $AufgNr => $aAufgabe ){
                        
                        $this->pdfUtility->Ln($lh/2);
                        
                        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , 'B' , $pageConf['fsize'] );
                        $str = $this->pdfUtility->llEncode( 'exercise_nr' ) . ' ' . $aAufgabe['Nr'];
                        $this->pdfUtility->Cell( 0 , $lh , $str , '' , 1 );
                        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , 'I' , $pageConf['fsize'] );

                        $subStr = $this->pdfUtility->encode( $aAufgabe['text']['Titel'] )  ;
                        $this->pdfUtility->Cell( $this->pdfUtility->GetStringWidth( $subStr ) + 1 , $lh , $subStr , '' , 1 );
                        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , '' , $pageConf['fsize'] );

                        $html = $aAufgabe['text']['Aufgabe'];
                        $this->pdfUtility->WriteHTML(  $this->pdfUtility->localchars( $html )  );
                        if( strpos($html,'</p>') == null && strpos($html,'<br>') == null){
                            $this->pdfUtility->Ln();
                        }

                        $str = $this->pdfUtility->llEncode('your_answer' ) . ': ';
                        $this->pdfUtility->Cell( $this->pdfUtility->GetStringWidth( $str ) , $lh , $str , '' , 0 );

                        $fontWeight = ( $aAufgabe['ergebnisPunkte'] == $aAufgabe['Punkte'] ) ? 'B' : '';
                        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , $fontWeight , $pageConf['fsize'] );
                        $str = $this->pdfUtility->encode( $aResult['data'][$AufgNr]['istAntwort'] . ' ' . $aResult['data'][$AufgNr]['istEinheit'] ) . '';
                        $this->pdfUtility->Cell( $this->pdfUtility->GetStringWidth( $str ) + 2 , $lh , $str , 'B' , 0 );

                        $fontWeight = 'B' ;
                        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , $fontWeight , $pageConf['fsize'] );
                        $str = '(' . $this->pdfUtility->llEncode('resulthint.reached_point' , [ $aAufgabe['ergebnisPunkte'] , $aAufgabe['Punkte'] ] )  . ')';
                        $this->pdfUtility->Cell( $this->pdfUtility->GetStringWidth( $str ) + 2 , $lh , $str , '' , 0 );
                        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , '' , $pageConf['fsize'] );
                        
                        if( $aAufgabe['ergebnisHinweis'] ){
                                $utf8string = $aAufgabe['ergebnisHinweis'] . ' ';
                                $utf8string .= LocalizationUtility::translate('tx_dreducalc.exam.resulthint.correct_answer','dr_educalc') . ': ';
                                $utf8string .= trim( $aAufgabe['antwort']['WerteText'] . ' ' . $aAufgabe['antwort']['EinheitText'])  . '. ' ;
                                $str = $this->pdfUtility->localchars( $utf8string );
                                $this->pdfUtility->SetFont( $pageConf['fontfamily'] , 'I' , round( $pageConf['fsize'] * 0.9 , 2 ) );
                                $this->pdfUtility->MultiCell( 0 , $lh , $str );
                                $this->pdfUtility->SetFont( $pageConf['fontfamily'] , '' , $pageConf['fsize'] );
                        }else{
                                $this->pdfUtility->Ln();
                        }
                        $y = $this->pdfUtility->GetY() + $lh / 4;
                        $this->pdfUtility->Line( $pageConf['leftMargin'] , $y , 210 - $pageConf['rightMargin'] , $y );
                }
		}
      
        $line = LocalizationUtility::translate('tx_dreducalc.exam.assessment.points','dr_educalc',[ $aResult['sum']['wertPunkteAnteil'] , $aResult['sum']['einheitPunkteAnteil'] ]) . '. ';
	    if( $this->settings['zeitabzug_maximalprozent'] ) {
            $line .= LocalizationUtility::translate('tx_dreducalc.exam.assessment.time','dr_educalc',[ $this->settings['zeitabzug_maximaldauer_prozent'] , $this->settings['zeitabzug_maximalprozent'] ]) . '. ';
        }
        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , 'I' , $pageConf['fsize']-2 );
        $this->pdfUtility->Ln();
        $this->pdfUtility->WriteHTML(  $this->pdfUtility->localchars( $line )  );
        $this->pdfUtility->Ln();
        $this->pdfUtility->SetFont( $pageConf['fontfamily'] , '' , $pageConf['fsize'] );
		
		$aOutType = $this->request->getArgument('pdf');
		$outputType = isset( $aOutType['open'] ) ? 'I' : 'D';
		
		echo $this->pdfUtility->Output( $docuname . '.pdf' , $outputType ); // D | I
		exit();

    }
    
}
