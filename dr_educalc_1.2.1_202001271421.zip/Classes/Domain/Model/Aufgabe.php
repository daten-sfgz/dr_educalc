<?php
namespace Dr\DrEducalc\Domain\Model;

use TYPO3\CMS\Extbase\Annotation as Extbase;

/***
 *
 * This file is part of the "EduCalc" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Aufgabe
 */
class Aufgabe extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * pid
     *
     * @var int
     */
    protected $pid = 0;

    /**
     * titel
     *
     * @var string
     */
    protected $titel = '';

    /**
     * aufgabe
     *
     * @var string
     */
    protected $aufgabe = '';

    /**
     * antwort
     *
     * @var string
     */
    protected $antwort = '';

    /**
     * toleranzwert
     *
     * @var string
     */
    protected $toleranzwert = '';

    /**
     * toleranzmin
     *
     * @var string
     */
    protected $toleranzmin = '';

    /**
     * toleranzmax
     *
     * @var string
     */
    protected $toleranzmax = '';

    /**
     * einheiten
     *
     * @var string
     */
    protected $einheiten = '';

    /**
     * zeitvorgabe
     *
     * @var int
     */
    protected $zeitvorgabe = 0;

    /**
     * punkte
     *
     * @var int
     */
    protected $punkte = 0;

    /**
     * formeln
     *
     * @var string
     */
    protected $formeln = '';

    /**
     * hilfetext
     *
     * @var string
     */
    protected $hilfetext = '';

    /**
     * sorting
     *
     * @var int
     */
    protected $sorting = 0;

    /**
     * gruppe
     *
     * @var int
     */
    protected $gruppe = 0;

    /**
     * versteckt
     *
     * @var int
     */
    protected $versteckt = 0;

    /**
     * Material
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Dr\DrEducalc\Domain\Model\Material>
     */
    protected $aufMat = null;

    /**
     * aufKat
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Dr\DrEducalc\Domain\Model\Kategorie>
     */
    protected $aufKat = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->aufMat = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->aufKat = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the pid
     *
     * @return string pid
     */
    public function getPid()
    {
        return $this->pid;
    }

    /**
     * Sets the pid
     *
     * @param string $pid
     * @return void
     */
    public function setPid($pid)
    {
        $this->pid = $pid;
    }

    /**
     * Returns the titel
     *
     * @return string titel
     */
    public function getTitel()
    {
        return $this->titel;
    }

    /**
     * Sets the titel
     *
     * @param string $titel
     * @return void
     */
    public function setTitel($titel)
    {
        $this->titel = $titel;
    }

    /**
     * Returns the aufgabe
     *
     * @return string aufgabe
     */
    public function getAufgabe()
    {
        return $this->aufgabe;
    }

    /**
     * Sets the aufgabe
     *
     * @param string $aufgabe
     * @return void
     */
    public function setAufgabe($aufgabe)
    {
        $this->aufgabe = $aufgabe;
    }

    /**
     * Returns the antwort
     *
     * @return string antwort
     */
    public function getAntwort()
    {
        return $this->antwort;
    }

    /**
     * Sets the antwort
     *
     * @param string $antwort
     * @return void
     */
    public function setAntwort($antwort)
    {
        $this->antwort = $antwort;
    }

    /**
     * Returns the toleranzwert
     *
     * @return string toleranzwert
     */
    public function getToleranzwert()
    {
        return $this->toleranzwert;
    }

    /**
     * Sets the toleranzwert
     *
     * @param string $toleranzwert
     * @return void
     */
    public function setToleranzwert($toleranzwert)
    {
        $this->toleranzwert = $toleranzwert;
    }

    /**
     * Returns the toleranzmin
     *
     * @return string toleranzmin
     */
    public function getToleranzmin()
    {
        return $this->toleranzmin;
    }

    /**
     * Sets the toleranzmin
     *
     * @param string $toleranzmin
     * @return void
     */
    public function setToleranzmin($toleranzmin)
    {
        $this->toleranzmin = $toleranzmin;
    }

    /**
     * Returns the toleranzmax
     *
     * @return string toleranzmax
     */
    public function getToleranzmax()
    {
        return $this->toleranzmax;
    }

    /**
     * Sets the toleranzmax
     *
     * @param string $toleranzmax
     * @return void
     */
    public function setToleranzmax($toleranzmax)
    {
        $this->toleranzmax = $toleranzmax;
    }

    /**
     * Returns the einheiten
     *
     * @return string einheiten
     */
    public function getEinheiten()
    {
        return $this->einheiten;
    }

    /**
     * Sets the einheiten
     *
     * @param string $einheiten
     * @return void
     */
    public function setEinheiten($einheiten)
    {
        $this->einheiten = $einheiten;
    }

    /**
     * Returns the zeitvorgabe
     *
     * @return int zeitvorgabe
     */
    public function getZeitvorgabe()
    {
        return $this->zeitvorgabe;
    }

    /**
     * Sets the zeitvorgabe
     *
     * @param int $zeitvorgabe
     * @return void
     */
    public function setZeitvorgabe($zeitvorgabe)
    {
        $this->zeitvorgabe = $zeitvorgabe;
    }

    /**
     * Returns the punkte
     *
     * @return int punkte
     */
    public function getPunkte()
    {
        return $this->punkte;
    }

    /**
     * Sets the punkte
     *
     * @param int $punkte
     * @return void
     */
    public function setPunkte($punkte)
    {
        $this->punkte = $punkte;
    }

    /**
     * Returns the formeln
     *
     * @return string formeln
     */
    public function getFormeln()
    {
        return $this->formeln;
    }

    /**
     * Sets the formeln
     *
     * @param string $formeln
     * @return void
     */
    public function setFormeln($formeln)
    {
        $this->formeln = $formeln;
    }

    /**
     * Returns the hilfetext
     *
     * @return string hilfetext
     */
    public function getHilfetext()
    {
        return $this->hilfetext;
    }

    /**
     * Sets the hilfetext
     *
     * @param string $hilfetext
     * @return void
     */
    public function setHilfetext($hilfetext)
    {
        $this->hilfetext = $hilfetext;
    }

    /**
     * Returns the sorting
     *
     * @return int sorting
     */
    public function getSorting()
    {
        return $this->sorting;
    }

    /**
     * Sets the sorting
     *
     * @param int $sorting
     * @return void
     */
    public function setSorting($sorting)
    {
        $this->sorting = $sorting;
    }

    /**
     * Returns the gruppe
     *
     * @return int gruppe
     */
    public function getGruppe()
    {
        return $this->gruppe;
    }

    /**
     * Sets the gruppe
     *
     * @param int $gruppe
     * @return void
     */
    public function setGruppe($gruppe)
    {
        $this->gruppe = $gruppe;
    }

    /**
     * Returns the versteckt
     *
     * @return int versteckt
     */
    public function getVersteckt()
    {
        return $this->versteckt;
    }

    /**
     * Sets the versteckt
     *
     * @param int $versteckt
     * @return void
     */
    public function setVersteckt($versteckt)
    {
        $this->versteckt = $versteckt;
    }

    /**
     * Adds a Material
     *
     * @param \Dr\DrEducalc\Domain\Model\Material $aufMat
     * @return void
     */
    public function addAufMat(\Dr\DrEducalc\Domain\Model\Material $aufMat)
    {
        $this->aufMat->attach($aufMat);
    }

    /**
     * Removes a Material
     *
     * @param \Dr\DrEducalc\Domain\Model\Material $aufMatToRemove The Material to be removed
     * @return void
     */
    public function removeAufMat(\Dr\DrEducalc\Domain\Model\Material $aufMatToRemove)
    {
        $this->aufMat->detach($aufMatToRemove);
    }

    /**
     * Returns the aufMat
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Dr\DrEducalc\Domain\Model\Material> aufMat
     */
    public function getAufMat()
    {
        return $this->aufMat;
    }

    /**
     * Sets the aufMat
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Dr\DrEducalc\Domain\Model\Material> $aufMat
     * @return void
     */
    public function setAufMat(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $aufMat)
    {
        $this->aufMat = $aufMat;
    }

    /**
     * Adds a Kategorie
     *
     * @param \Dr\DrEducalc\Domain\Model\Kategorie $aufKat
     * @return void
     */
    public function addAufKat(\Dr\DrEducalc\Domain\Model\Kategorie $aufKat)
    {
        $this->aufKat->attach($aufKat);
    }

    /**
     * Removes a Kategorie
     *
     * @param \Dr\DrEducalc\Domain\Model\Kategorie $aufKatToRemove The Kategorie to be removed
     * @return void
     */
    public function removeAufKat(\Dr\DrEducalc\Domain\Model\Kategorie $aufKatToRemove)
    {
        $this->aufKat->detach($aufKatToRemove);
    }

    /**
     * Returns the aufKat
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Dr\DrEducalc\Domain\Model\Kategorie> aufKat
     */
    public function getAufKat()
    {
        return $this->aufKat;
    }

    /**
     * Sets the aufKat
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Dr\DrEducalc\Domain\Model\Kategorie> $aufKat
     * @return void
     */
    public function setAufKat(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $aufKat)
    {
        $this->aufKat = $aufKat;
    }
}
