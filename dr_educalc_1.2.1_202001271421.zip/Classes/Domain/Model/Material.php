<?php
namespace Dr\DrEducalc\Domain\Model;

use TYPO3\CMS\Extbase\Annotation as Extbase;

/***
 *
 * This file is part of the "EduCalc" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Material
 */
class Material extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * pid
     *
     * @var int
     */
    protected $pid = 0;

    /**
     * tabellenname
     *
     * @var string
     * @Extbase\Validate(validator="NotEmpty")
     */
    protected $tabellenname = '';

    /**
     * felder
     *
     * @var string
     */
    protected $felder = '';

    /**
     * tabelle
     *
     * @var string
     */
    protected $tabelle = '';

    /**
     * sorting
     *
     * @var int
     */
    protected $sorting = 0;

    /**
     * versteckt
     *
     * @var int
     */
    protected $versteckt = 0;

    /**
     * Returns the pid
     *
     * @return string pid
     */
    public function getPid()
    {
        return $this->pid;
    }

    /**
     * Sets the pid
     *
     * @param string $pid
     * @return void
     */
    public function setPid($pid)
    {
        $this->pid = $pid;
    }

    /**
     * Returns the tabellenname
     *
     * @return string tabellenname
     */
    public function getTabellenname()
    {
        return $this->tabellenname;
    }

    /**
     * Sets the tabellenname
     *
     * @param string $tabellenname
     * @return void
     */
    public function setTabellenname($tabellenname)
    {
        $this->tabellenname = $tabellenname;
    }

    /**
     * Returns the felder
     *
     * @return string felder
     */
    public function getFelder()
    {
        return $this->felder;
    }

    /**
     * Sets the felder
     *
     * @param string $felder
     * @return void
     */
    public function setFelder($felder)
    {
        $this->felder = $felder;
    }

    /**
     * Returns the tabelle
     *
     * @return string tabelle
     */
    public function getTabelle()
    {
        return $this->tabelle;
    }

    /**
     * Sets the tabelle
     *
     * @param string $tabelle
     * @return void
     */
    public function setTabelle($tabelle)
    {
        $this->tabelle = $tabelle;
    }

    /**
     * Returns the sorting
     *
     * @return int sorting
     */
    public function getSorting()
    {
        return $this->sorting;
    }

    /**
     * Sets the sorting
     *
     * @param int $sorting
     * @return void
     */
    public function setSorting($sorting)
    {
        $this->sorting = $sorting;
    }

    /**
     * Returns the versteckt
     *
     * @return int versteckt
     */
    public function getVersteckt()
    {
        return $this->versteckt;
    }

    /**
     * Sets the versteckt
     *
     * @param int $versteckt
     * @return void
     */
    public function setVersteckt($versteckt)
    {
        $this->versteckt = $versteckt;
    }
}
