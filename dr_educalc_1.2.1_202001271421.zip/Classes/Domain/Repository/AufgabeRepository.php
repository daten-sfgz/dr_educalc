<?php
namespace Dr\DrEducalc\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;

/***
 *
 * This file is part of the "EduCalc" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * The repository for Aufgabes
 */
class AufgabeRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    /**
     * @var array
     */
    protected $defaultOrderings = [
        'gruppe' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
        'sorting' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
    ];
    
    /**
     * Always return hidden and deleted records from this Repository
     */
    public function initializeObject() {
        $querySettings = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');

        // Get Hidden and Deleted Records
        $querySettings->setIgnoreEnableFields(false);
        $querySettings->setIncludeDeleted(false);

         $this->setDefaultQuerySettings($querySettings);
    }
    
	  /**
	  *  Find data from Aufgabe 
	  *   with given PIDs where 'versteckt' = 0
	  * 
      * @param string $pidList comma separed list with pid's
	  * @return void
	  */
    public function findByPidAndNotVersteckt( $pidList ) {
	      $aPids = explode( ',' , $pidList );
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setIgnoreEnableFields(false);
 	      $querySettings->setRespectStoragePage(true);
 	      $querySettings->setStoragePageIds( $aPids );
	      $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      $constraints = [];
          $constraints[] = $query->equals( 'versteckt', 0 );
//           $constraints[] = $query->in('pid', $aPids );
	      $query->matching(
		    $query->logicalAnd( $constraints )
	      );
	      return $query->execute();
    }
    
	  /**
	  *  Find data from Aufgabe 
	  *   with given Material or Kategorie Pid
	  *   
	  * 
      * @param array $uidList comma separed list with uid's
      * @param string $subtable eg aufMat or aufKat
      * @param string $pidList comma separed list with pid's
      * @param string $andOr AND or OR case insensitive
	  * @return void
	  */
    public function findNotVerstecktInPidBySubtable( $uidList , $subtable = 'aufMat' , $pidList , $andOr = 'or' ) {
	      $aPids = explode( ',' , $pidList );
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
 	      if( count($aPids) ){
            $querySettings->setIgnoreEnableFields(false);
            $querySettings->setRespectStoragePage(true);
            $querySettings->setStoragePageIds( $aPids );
            $this->setDefaultQuerySettings($querySettings);
 	      }
	      $query = $this->createQuery();
	      $constraints = [];
          if( is_array($uidList) && count($uidList) ){
                foreach( $uidList as $uid => $isValid ) {
                        if( $isValid ) $constraints[] = $query->contains( $subtable , $uid );
                }
          }
          if( count($constraints) ){
                $condType = strtolower($andOr) == 'or' ? 'logicalOr' : 'logicalAnd';
                $query->matching(
                    $query->logicalAnd( $query->equals( 'versteckt', 0 ) , $query->$condType( $constraints ) )
                );
	      }else{
                $query->matching(
                    $query->equals( 'versteckt', 0 )
                );
	      }
	      return $query->execute();
    }
    
	  /**
	  *  Find data from Aufgabe 
	  *   with given Material in all pages
	  * 
      * @param array $uidList comma separed list with uid's
      * @param string $subtable eg aufMat or aufKat
      * @param boolean $bAllPages search on all pages, default is false (search only in registered pid's)
      * @param string $andOr AND or OR case insensitive
	  * @return void
	  */
    public function findAllBySubtable( $uidList , $subtable = 'aufMat' , $bAllPages = false , $andOr = 'or' ) {
	      if( $bAllPages ){
                $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
                $querySettings->setIgnoreEnableFields( true );
                $querySettings->setRespectStoragePage( false );
                $this->setDefaultQuerySettings($querySettings);
	      }
	      $query = $this->createQuery();
	      $constraints = [];
          if( is_array($uidList) && count($uidList) ){
                foreach( $uidList as $uid => $isValid ) if( $isValid ) $constraints[] = $query->contains( $subtable , $uid );
	      }
          if( count($constraints) ){
                $condType = strtolower($andOr) == 'or' ? 'logicalOr' : 'logicalAnd';
                $query->matching(
                    $query->$condType( $constraints )
                );
	      }
	      return $query->execute();
    }
    
	  /**
	  *  Find data from Aufgabe 
	  *   with given PIDs
	  * 
      * @param string $pidList comma separed list with pid's
	  * @return void
	  */
    public function findAllByPid( $pidList ) {
	      $aPids = explode( ',' , $pidList );
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setIgnoreEnableFields(true);
	      
 	      if( count($aPids) ){
            $querySettings->setRespectStoragePage( true );
            $querySettings->setStoragePageIds( $aPids );
            
 	      }
 	      
	      $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      return $query->execute();
    }
}
