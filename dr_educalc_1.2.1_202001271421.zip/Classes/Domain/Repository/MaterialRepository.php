<?php
namespace Dr\DrEducalc\Domain\Repository;

/***
 *
 * This file is part of the "EduCalc" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * The repository for Materials
 */
class MaterialRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    /**
     * @var array
     */
    protected $defaultOrderings = [
        'sorting' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
    ];
    
    /**
     * Always return hidden and deleted records from this Repository
     */
    public function initializeObject() {
        $querySettings = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');

        // DO NOT Get Hidden and Deleted Records
        $querySettings->setIgnoreEnableFields(false);
        $querySettings->setIncludeDeleted(false);

        //Disable Storage pid
//         $querySettings->setRespectStoragePage(false);
         $this->setDefaultQuerySettings($querySettings);
	}
    
	  /**
	  *  Find data from Material 
	  *   with given PIDs
	  * 
      * @param string $pidList comma separed list with pid's
	  * @return void
	  */
    public function findAllByPid( $pidList ) {
	      $aPids = explode( ',' , $pidList );
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setIgnoreEnableFields(true);
	      
 	      if( count($aPids) ){
            $querySettings->setRespectStoragePage( true );
            $querySettings->setStoragePageIds( $aPids );
            
 	      }
 	      
	      $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      return $query->execute();
    }
}
