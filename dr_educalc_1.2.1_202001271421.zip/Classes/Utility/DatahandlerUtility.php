<?php
namespace Dr\DrEducalc\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class DatahandlerUtility
 * 
 */

class DatahandlerUtility {

    /**
     * errorMessage
     *
     * @var string
     */
    Public $errorMessage = '';

    /**
     * constructor
     *
     * @return void
     */
    public function __construct()
    {
		$this->persistenceManager = GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
		$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->sessionUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\SessionUtility');
    }

    /**
     * moveObjectInRepository
     *
     * @param int $uid content-uid to move
     * @param str $direction [ up | down ] default is 'up' or empty
     * @param TYPO3\CMS\Extbase\Persistence\Repository $repository
     * @return boolean
     */
    Public function moveObjectInRepository( int $uid , string $direction , \TYPO3\CMS\Extbase\Persistence\Repository $repository)
    {
			$table = $repository->findAll();
			return $this->moveObjectOnGivenArray( $uid , $direction , $repository , $table );
    }

    /**
     * moveObjectInRepository
     *
     * @param int $uid content-uid to move
     * @param str $direction [ up | down ] default is 'up' or empty
     * @param TYPO3\CMS\Extbase\Persistence\Repository $repository
     * @param array $table
     * @return boolean
     */
    Public function moveObjectOnGivenArray( int $uid , string $direction , \TYPO3\CMS\Extbase\Persistence\Repository $repository , $table )
    {
			if( !count( $table ) ) return false;

			$posOtherIx = $direction == 'up' || empty($direction) ? -1 : +1;

			foreach( $table as $ix => $objAufgabe ){
				
				if( $uid == $objAufgabe->getUid() ){
					// detect the other item to flip with: add or substract 1 to actual position (ix)
					$otherIx = $ix + $posOtherIx;
					// add to the moving item +0 or +2
					$table[$ix]->setSorting( $ix + 1 + $posOtherIx );
					// add to the item to flip with +1
					$table[$otherIx]->setSorting( $ix + 1 );
					// update the item to flip with
					$repository->update($table[$otherIx]);
					
					// special treatment for grouped table like aufgabe
					if( method_exists( $table[$otherIx] , 'getGruppe' ) ){
                        // copy the group of targeting item
                        $otherGroup = $table[$otherIx]->getGruppe();
                        $table[$ix]->setGruppe( $otherGroup );
					}

				}elseif( !isset($otherIx) || $ix != $otherIx ){
					// not one of the two moving items: add 1
					$table[$ix]->setSorting( $ix + 1 );
					
				}
				
				// update the item
				$repository->update($table[$ix]);
				
			}
			
			$this->persistenceManager->persistAll();
			return true;
    }

    /**
     * updateMultipleRowsInRepository
     *
     * @param array $aRowsWithNewValues
     * @param string $field_name in lowercase and underline-writing
     * @param TYPO3\CMS\Extbase\Persistence\Repository $repository
     * @return boolean
     */
    Public function updateMultipleRowsInRepository( array $aRowsWithNewValues , string $field_name , \TYPO3\CMS\Extbase\Persistence\Repository $repository )
    {
			$lcField = strtolower($field_name);
			$aFldName = explode( '_' , $field_name );
			$uccField = '';
			foreach( $aFldName as $chr ) $uccField .= ucFirst($chr);
			$getFunct = 'get' . $uccField;
			$setFunct = 'set' . $uccField;
			
			// find all, collect in objects-list
			$aRawObjects = $repository->findAll();
			if( !is_array($aRowsWithNewValues) || !isset($aRowsWithNewValues[$lcField]) || !is_array($aRowsWithNewValues[$lcField]) ) return false;
					
			// replace index with uid: loop through all objects in list and recollect
			foreach( $aRawObjects as $ix => $objAufgabe ) $aObjects[ $objAufgabe->getUid() ] = $objAufgabe;
			
			// Compare group in object with group in inputs. 
			$changes = 0;
			foreach( $aRowsWithNewValues[$lcField] as $uid => $groupvalue ){
				if( !isset($aObjects[$uid]) || $aObjects[$uid]->$getFunct() == $groupvalue ) continue;
				// if changes are done then change value, update object and iterate the counter '$changes'
				$aObjects[$uid]->$setFunct($groupvalue);
				$repository->update($aObjects[$uid]);
				++$changes;
			}
			// if no changes are done, then return the initial objects-list
			if( !$changes ) return false;
			
			$this->persistenceManager->persistAll();
			return true;
    }

    /**
     * enrichPagesWithStoragePidsFromTs
     *
     * @param string $sPages
     * @param string $pluginKey
     * @return string
     */
    Public function enrichPagesWithStoragePidsFromTs( $sPages , $pluginKey = 'tx_dreducalc_eced' )
    {
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$this->typoScriptService =  $this->objectManager->get('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
		$pluginKey = 'tx_dreducalc_eced';
		$storagePids = $fullsettings['plugin.'][ $pluginKey . '.' ]['persistence.']['storagePid'];
		
		$aPids = explode( ',' , $storagePids ) ;
		$aPages = explode( ',' , $sPages ) ;
		$aMerged = array_merge( $aPids , $aPages );
		
		$aValue2key = array_flip( $aMerged );
		
		// dont let empty values set as pid = 0 (to  prevent the missunderstandings)
		if( isset($aValue2key['']) ) unset($aValue2key['']);
		
		$sAll = implode( ',' , array_keys( $aValue2key ) );
		return $sAll;
    }

    /**
     * getSessDataForPids
     *  returns the filtered session data
     *
     * @param str $sessSubKey 
     * @param string $strPidList comma separed list with pid's
     * @return array [ strFiltername1 => [ intUidA => bolChecked ] ]
     */
    Public function getSessDataForPids( $sessSubKey , $strPidList )
    {
            $sessFilter = $this->sessionUtility->getData();
            $filteredSessFilter = $this->getFilterItemsByPids( $sessFilter , $strPidList ) ;
            return $filteredSessFilter[$sessSubKey] ;
    }

    /**
     * getPidsOfFilterItems
     *  returns the filtered incomed array 
     *
     * @param array $aDeepFilter [ strFiltername1 => [ intUidA => bolChecked , intUidB => bolChecked ] , strFiltername2 => [...] ]
     * @param string $strPidList comma separed list with pid's
     * @return array [ strFiltername1 => [ intUidA => bolChecked ] ]
     */
    Public function getFilterItemsByPids( $aDeepFilter , $strPidList )
    {
            $this->errorMessage = ''; // reset errorMessage string
            
            $aFilterWithPids = $this->getPidsOfFilterItems( $aDeepFilter ); 
            $aPossiblePids = array_flip( explode( ',' , $strPidList ) ); // [ pid1 => 0 , pid2 => 1 , ... ]
            
            foreach( $aFilterWithPids as $sType => $aFilterGroup ){
                    foreach( $aFilterGroup as $pid => $aFilter ){
                        if( !isset($aPossiblePids[$pid]) ){
                            foreach( array_keys($aFilter) as $uid ) unset($aDeepFilter[$sType][$uid]);
                        }
                    }
            }
            return $aDeepFilter;

    }

    /**
     * getPidsOfFilterItems
     *  returns a array similar to the incomed, but one dimension deeper: in 2-nd dim now is the pid, 3-rd dim is uid and value
     * 
     * @param array $aDeepFilter [ strFiltername1 => [ intUidA => bolChecked , intUidB => bolChecked ] , strFiltername2 => [...] ]
     * @return array [ strFiltername1 => [ Pid35 => [ intUidA => bolChecked ] , Pid36 => [ intUidB => bolChecked ] ] ]
     */
    Private function getPidsOfFilterItems( $aDeepFilter )
    {
            $aFilterWithPids = [];
            if( !is_array($aDeepFilter) || !count($aDeepFilter) ) return $aFilterWithPids;
            
            $repBasename = 'Dr\\DrEducalc\\Domain\\Repository\\#Repository';
            
            foreach( $aDeepFilter as $sType => $aFilter ){
                    if( $sType == 'kategorie' || $sType == 'material' ){ // seek for pid's by given uid's in subtables of aufgabe 
                            $class = str_replace( '#' , ucFirst( $sType ) , $repBasename );
                            if( class_exists( $class ) ) {
                                    $rep = $this->objectManager->get( $class );
                                   foreach( $aFilter as $uid => $bChecked ){
                                        $objSubtable = $rep->findByUid($uid);
                                        if( $objSubtable ){
                                            $pidSub = $objSubtable->getPid();
                                            $aFilterWithPids[$sType][$pidSub][$uid] = $bChecked;
                                        }
                                    }
                            }else{
                                    $this->errorMessage = trim( $this->errorMessage . ' Klasse ' . $class . ' nicht gefunden.' ) ;
                            }
                    }
            }
            return $aFilterWithPids;
    }

    /**
     * getUsedKategorienFilter
     * built for AufgabeController->listAction()
     * built for RunController->tryalAction() and ->examAction
     *
     * @param array $aAufgabes
     * @return array
     */
    Public function getUsedKategorienFilter( $aAufgabes )
    {
            if( ( !is_array($aAufgabes) && !is_object($aAufgabes) ) || !count($aAufgabes) ) return [];
            
            $sessFilter = $this->sessionUtility->getData( 'kategorie' );
            
            $aUsorted = [];
            foreach( $aAufgabes as $ix => $aufgabe ){
                    $aoKategorien = $aufgabe->getAufKat();
                    foreach( $aoKategorien as $oKat ){
                        $iKatUid = $oKat->getUid();
                        $sel = isset( $sessFilter[$iKatUid] ) && 1 == $sessFilter[$iKatUid] ? 'checked' : '';
                        $aUsorted[$oKat->getSorting()][$iKatUid] = [ 'Kategorie'=>$oKat->getKategorie() , 'checked'=> $sel ];
                    }
            }
            if( !count($aUsorted) ) return;
            
            ksort($aUsorted);
            $aKatNrs = [];
            foreach( $aUsorted as $aSorted ) $aKatNrs[key($aSorted)] = current($aSorted);
            
            return $aKatNrs;
    }

    /**
     * getAufgabeGruppeOptions
     * built for AufgabeController->listAction()
     *
     * @param array $aAufgabes
     * @return array
     */
    Public function getAufgabeGruppeOptions( $aAufgabes )
    {
        // create options with all groups for the group select-fields
        $aOptions = [];
        $passedGroup = NULL;
        
        foreach( $aAufgabes as $ix => $obj ){ 
			$group = $obj->getGruppe(); 
			// nothing to do if this group was already registered
			if( $passedGroup == $group ) continue;
			// calculate the middle between passed and actual group
			$middle = ceil( ($passedGroup + $group) /2 );
			// round to 5 if step is bigger than 10
			if( ($group - $passedGroup) > 10 ){
				$middle = round( $middle / 5 ) * 5;
			}
			// assign the actual and the middle step
			$aOptions[$middle] = $middle;
			$aOptions[$group] = $group;
			// set actual group to passed group
			$passedGroup = $group;
		}
        // calculate and assign the middle between last group and the group behind the last group
		$last = ceil( $passedGroup / 10 + 1 ) * 10;
		$aOptions[$last] = $last;
        ksort($aOptions);
        
        if( isset($aOptions[0]) ) unset($aOptions[0]);
        return $aOptions;
    }

    /**
     * getMnTablesForCheckboxes
     * built for AufgabeController->editAction()
     *
     * @param array $aSubTableRepository
     * @param array $aAllTableRepository
     * @return array
     */
    Public function getMnTablesForCheckboxes( $aSubTableRepository , $aAllTableRepository )
    {
        $preselected = [];
        $srtPresel = [];
        $aSort = [];
        foreach($aSubTableRepository as $tabKey => $tabObj ){
			
			if( !$tabObj || !count($tabObj) ) continue;
			
			foreach( $tabObj as $selTab ) {
                $uid = $selTab->getUid();
                $srtPresel[$tabKey][$uid] = [ 'css' => 'disabled' , 'checked' => 'checked' , 'data' => $selTab ];
                $aSort[$tabKey][$uid] = $selTab->getSorting();
            }
        }

        foreach($aAllTableRepository as $tabKey => $tabObj ){
			if( !$tabObj || !count($tabObj) ) continue;
			foreach( $tabObj as $selTab ) {
                if( $selTab->getVersteckt() ) continue;
                $uid = $selTab->getUid();
                $srtPresel[$tabKey][$uid] = [ 'css' => 'enabled' , 'checked' => ( isset($srtPresel[$tabKey][$uid]) ? 'checked' : '' ) , 'data' => $selTab ];
                $aSort[$tabKey][$uid] = $selTab->getSorting();
            }
        }
        // glue them together to $preselected['tables']
        // keep always the same sort order: loop through array_keys( $aAllTableRepository )
        foreach( array_keys( $aAllTableRepository ) as $tabKey ){
                //  instead of looping like ...each( $aSort as $tabKey => $sortObj )... we dont need the the $sortObj here
                asort($aSort[$tabKey]);
                foreach( array_keys($aSort[$tabKey]) as $uid ){
                   $preselected[$tabKey][$uid] = $srtPresel[$tabKey][$uid];
                }
        }
        return $preselected;
    }

    /**
     * validateAufgabe
     * built for AufgabeController->editAction()
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @param array $aFormulas
     * @return array
     */
    Public function validateAufgabe( \Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe , $aFormulas = [] )
    {
            $kategorie = $aufgabe->getAufKat();
            $antwort = $aufgabe->getAntwort();
            $einheiten = $aufgabe->getEinheiten();
            $zeit = $aufgabe->getZeitvorgabe();
            
            $aValidCounter['auf_kat'] = ( false != $kategorie && count($kategorie) ) ? 1 : 0;
            $aValidCounter['antwort'] = isset($aFormulas[$antwort]) && !empty($aFormulas[$antwort]) && is_numeric($aFormulas[$antwort]) ? 1 : 0;
            $aValidCounter['einheiten'] = !empty($einheiten) && !is_numeric($einheiten)  ? 1 : 0;
            $aValidCounter['zeitvorgabe'] = !empty($zeit) && is_numeric($zeit) ? 1 : 0;
            
            $aErrMess['antwort'] = [ true => 'Nicht numerisch' , false => 'leer' ];
            
            return [
                    'errors' => count($aValidCounter) - array_sum($aValidCounter) ,
                    'details' => [
                            'auf_kat'=>   [
                                'message'=>'Ok' , 
                                'errmess'=>'Keine Kategorie!' , 
                                'valid'=> $aValidCounter['auf_kat'] 
                            ] , 
                            'antwort'=>   [
                                'message'=>'Ok ' . (isset($aFormulas[$antwort]) ? ": '" . $aFormulas[$antwort] . "'" : '' ) , 
                                'errmess'=> $aErrMess['antwort'][isset($aFormulas[$antwort]) && !empty($aFormulas[$antwort]) ] . (isset($aFormulas[$antwort]) ? ": '" . $aFormulas[$antwort] . "'" : '' ) , 
                                'valid'=>  $aValidCounter['antwort']
                            ] , 
                            'einheiten'=> [
                                'message'=>"Ok '"  . $einheiten . "'"   , 
                                'errmess'=>"Leer oder numerisch '"  . $einheiten . "'"   , 
                                'valid'=> $aValidCounter['einheiten']
                            ] , 
                            'zeitvorgabe'=> [
                                'message'=> "Ok  '" . $zeit . "'"  , 
                                'errmess'=> "Leer oder nicht numerisch  '" . $zeit . "'"  , 
                                'valid'=> $aValidCounter['zeitvorgabe']
                            ]
                    ] 
            ];
    }
 
}
