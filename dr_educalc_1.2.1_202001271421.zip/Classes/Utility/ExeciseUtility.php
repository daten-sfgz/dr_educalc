<?php
namespace Dr\DrEducalc\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility ;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class ExeciseUtility
 * 
 */

class ExeciseUtility {

    /**
     * formulaUtility
     *
     * @var \Dr\DrEducalc\Utility\FormulaUtility
     */
    protected $formulaUtility = null;

    /**
     * aufgabeRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\AufgabeRepository
     */
    protected $aufgabeRepository = null;

    /**
     * aAufgabes
     *
     * @var object
     */
    protected $aAufgabes = null;

    /**
     * iAmount
     *
     * @var int
     */
    protected $iAmount = 1;

    /**
     * iGrouped
     *
     * @var int
     */
    protected $iGrouped = 0;

    /**
     * aMarker
     *
     * @var array
     */
    protected $aMarker = null;

    /**
     * aCompressed
     *
     * @var array
     */
    protected $aCompressed = [ 'ant'=>'sollAntwort' , 'min'=>'minAntwort' , 'max'=>'maxAntwort' , 'ein'=>'Einheiten' , 'zeit'=>'Zeitvorgabe' , 'pkt'=>'Punkte' ];

    /**
     * constructor
     *
     * @return void
     */
    public function __construct()
    {
		$this->formulaUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\FormulaUtility');
		
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->aufgabeRepository = $objectManager->get('Dr\\DrEducalc\\Domain\\Repository\\AufgabeRepository');
    }

    /**
     * calculateResults 
     *
     * @param array $aAufgabes
     * @param array $aSettings
     * @param boolean $acceptEmptyValue counts units as partly point if true
     * @return array
     */
    Public function calculateResults( $aAufgabes , $aSettings , $acceptEmptyValue = false)
    {
// 	    FIXME forces time to overdue for 25%
// 	    $aAufgabes['istZeit'] = (425 + $aSettings['zeitabzug_maximaldauer_prozent']) /100 * $aAufgabes['sollZeit'];

	    $wertGewichtProzent = 100 - $aSettings['gewichtung_einheit_prozent'] ;
	    
	    $sum['wertPunkteAnteil'] = round( $wertGewichtProzent / 100 , 2 );
	    $sum['einheitPunkteAnteil'] = 1-$sum['wertPunkteAnteil'];
	    
	    $aAssIntPoints = [ 0 => 1 , 1 => $sum['wertPunkteAnteil'] , 2 => ( $acceptEmptyValue ? $sum['einheitPunkteAnteil'] : 0 ) , 3 => 0 ];
		
		$transl_1 = LocalizationUtility::translate('tx_dreducalc.exam.assessment.errortext.1','dr_educalc') . '.';
		$transl_2 = LocalizationUtility::translate('tx_dreducalc.exam.assessment.errortext.2','dr_educalc') . '.';
		$transl_3 = LocalizationUtility::translate('tx_dreducalc.exam.assessment.errortext.3','dr_educalc') . '.';
	    $aAssStr = [ 0 => '' , 1 => $transl_1 , 2 => $transl_2 , 3 => $transl_3 ];
	    
	    // calculate aggregate
		$aPtSum = [];
		if( isset($aAufgabes['data']) && is_array($aAufgabes['data']) ){
                foreach($aAufgabes['data'] as $AufgNr => $aAufgabe ){
                        $dat[$AufgNr] = $aAufgabe;
                        $dat[$AufgNr]['istAntwort']  = $aAufgabes['result'][$AufgNr]['istAntwort'];
                        $dat[$AufgNr]['istEinheit']  = $aAufgabes['result'][$AufgNr]['istEinheit'];
                        $ergebnisCode = $this->calculateAssessment( $aAufgabes['result'][$AufgNr] , $aAufgabe['antwort'] ); // 0 | 1 | 2 | 3
                        $dat[$AufgNr]['Punkte'] =  $aAufgabe['antwort']['Punkte'] ? $aAufgabe['antwort']['Punkte'] : 1 ;
                        $dat[$AufgNr]['ergebnisPunkte'] = $dat[$AufgNr]['Punkte'] * $aAssIntPoints[$ergebnisCode];
                        $dat[$AufgNr]['ergebnisHinweis'] = $aAssStr[$ergebnisCode];
                        $aPtSum[] = $dat[$AufgNr]['ergebnisPunkte'];
                        $aPtMax[] = $dat[$AufgNr]['Punkte'];
                }
	    }
	    $sum['maximalPunkte'] = array_sum( $aPtMax );
	    $sum['erreichtePunkte'] = array_sum($aPtSum);
	    $sum['punkteNote'] = $sum['maximalPunkte'] ? round( $sum['erreichtePunkte'] * 5 / $sum['maximalPunkte'] , 4 ) + 1 : 6; // error handling: prevent division by zero
	    $sum['endNote'] = $sum['punkteNote'];
	    $sum['abzugZeitNote'] = 0;
	    $sum['istZeit'] = $aAufgabes['istZeit'];
	    $sum['sollZeit'] = $aAufgabes['sollZeit'];
	    $sum['name'] = $aAufgabes['name'];
    
	    if( $sum['istZeit'] > $sum['sollZeit'] && !empty( $aSettings['zeitabzug_maximalprozent'] ) && !empty( $aSettings['zeitabzug_maximaldauer_prozent'] ) ){
            $diffSec = $sum['istZeit'] - $sum['sollZeit']; // zb sind 135 S. von 90 S. 45 S. Differenz: 135 - 90 = 45
            // zb sind 135 S. von 90 S. 50% ueberschreitung: 45 S. / 90 S. * 100% [ 0 ... 9999 ]
            $sum['mehrZeitProzent'] = $sum['sollZeit'] ? $diffSec / $sum['sollZeit'] * 100 : 0 ; // error handling: prevent division by zero
            
            $abzugProzent = $sum['mehrZeitProzent'] / ( $aSettings['zeitabzug_maximaldauer_prozent'] / 100 );
            $abzugProzGewichtet = $sum['mehrZeitProzent'] > $aSettings['zeitabzug_maximaldauer_prozent'] ? $aSettings['zeitabzug_maximalprozent'] :$aSettings['zeitabzug_maximalprozent'] / 100 * $abzugProzent;
            $abzugNote = round( $abzugProzGewichtet / 100 * ( $sum['punkteNote'] -1 ) , 2 );
            
            // ABZUG nur wenn >= 4 bei settings['zeitabzug_ab_note'] = 4
            $punktenoteGerundet = round( $sum['punkteNote'] , 1 ); 
            if( $punktenoteGerundet - $abzugNote > $aSettings['zeitabzug_ab_note'] ) { // punktenote > ( 4 + Abzug )
                $sum['abzugZeitNote'] = $abzugNote;
                
            }elseif( $punktenoteGerundet > $aSettings['zeitabzug_ab_note'] ){ // punktenote > 4
                $sum['abzugZeitNote'] = $punktenoteGerundet - $aSettings['zeitabzug_ab_note'];
                
            }else{ // punktenote <= 4
                $sum['abzugZeitNote'] = 0;
            }
            
            $sum['endNote'] -= $sum['abzugZeitNote'];
	    }
	    
	    $sum['endNoteGerundet'] = round( $sum['endNote'] , 1 );
	    return [ 'data' => $dat , 'sum' => $sum , 'settings' => $aSettings ];
    }

    /**
     * calculateAssessment
     * returns 
     *  0 if all condditions where accepted
     *  1 if unit is wrong
     *  2 if value is wrong
     *  3 if both is wrong
     *
     * @param array $aGivenAnswer [ istAntwort , istEinheit ]
     * @param array $aAcceptedAnswers [ sollAntwort , Einheiten [, minAntwort , maxAntwort] ]
     * @return int
     */
    Private function calculateAssessment( $aGivenAnswer , $aAcceptedAnswers )
    {
        $checkValue = 2;
        $checkUnit = 1;
        $errorSum = 0;
        
        if( isset($aAcceptedAnswers['sollAntwort']) ) {
                if( !isset($aGivenAnswer['istAntwort']) ){
                    $errorSum += $checkValue;
                }else{
                    $given = $aGivenAnswer['istAntwort'];
                    $min = isset($aAcceptedAnswers['minAntwort']) ? $aAcceptedAnswers['minAntwort'] : $aAcceptedAnswers['sollAntwort'];
                    $max = isset($aAcceptedAnswers['maxAntwort']) ? $aAcceptedAnswers['maxAntwort'] : $aAcceptedAnswers['sollAntwort'];
                    if( $given < $min || $given > $max ) $errorSum += $checkValue;
                }
        }
        
        if( isset($aAcceptedAnswers['Einheiten']) ) {
                if( !isset($aGivenAnswer['istEinheit']) ){
                    $errorSum += $checkUnit;
                }else{
                    $sAnswerUnit = trim( strtolower( $aGivenAnswer['istEinheit'] ) , '.' );
                    $aAcceptUnit = explode( ',' , strtolower( str_replace( '.' , '' , $aAcceptedAnswers['Einheiten'] ) ) );
                    $foundIx = array_search( $sAnswerUnit , $aAcceptUnit );
                    if( $aAcceptUnit[$foundIx] != $sAnswerUnit ) $errorSum += $checkUnit;
                }
        }
        
        return $errorSum;
    }

    /**
     * getCompressedExamesList
     * for transport purpose, receaves only neccessary variables
     * here we read raw text  with keywords in it from repository and replace it with transmitted values
     *
     * @param array $aAufgabes array of variables
     * @return array
     */
    Public function decompressExamesList( $aAufgabes )
    {
            foreach( $aAufgabes['data'] as $aIx => $aComressedAufgabe ) {
                    $aAufgabe = [ 'Nr' => $aIx ];
                    $aDecPair = explode( '+++' , $aComressedAufgabe );
                    
                    $dec['soll'] = explode( '+' , $aDecPair[0] );
                    foreach( $dec['soll'] as $pair ){
                            $aVarVal = explode( '=' , $pair );
                            $keynam = isset( $this->aCompressed[$aVarVal[0]] ) ? $this->aCompressed[$aVarVal[0]] : $aVarVal[0];
                            $aAufgabe['antwort'][$keynam] = $aVarVal[1];
                    }
                    $aAufgabe['uid'] = 0 + $aAufgabe['antwort']['uid'];
                    unset($aAufgabe['antwort']['uid']);
                    
                    $dec['variables'] = explode( '+' , $aDecPair[1] );
                    foreach( $dec['variables'] as $pair ){
                        $aVarVal = explode( '=' , $pair );
                        $aAufgabe['variables'][$aVarVal[0]] = $aVarVal[1];
                    }
                    
                    // get the object
                    $oAugfabe = $this->aufgabeRepository->findByUid( $aAufgabe['uid'] );
                    // get original plain text with keywords in it
                    $aAufgabe['text']['Aufgabe'] = $oAugfabe->getAufgabe();
                    $aAufgabe['text']['Hilfetext'] = $oAugfabe->getHilfetext();
                    
                    // variable replacement in text fields
                    if( count($aAufgabe['variables']) ){
                            $aSortVars = $this->formulaUtility->getArrayKeysSortedAndNumberFormatted($aAufgabe['variables']);
                            foreach($aSortVars as $variable => $content ){
                                    foreach( $aAufgabe['text'] as $textField => $textContent ) {
                                        $aAufgabe['text'][$textField] = str_replace( '$' . $variable , $content , $textContent );
                                    }
                            }
                    }
                    // no replacing in title
                    $aAufgabe['text']['Titel'] = $oAugfabe->getTitel();
                    $aAufgabes['data'][$aIx] = $aAufgabe;
                    
                    $aEinht = explode( ',' , $aAufgabe['antwort']['Einheiten'] );
                     $aAufgabes['data'][$aIx]['antwort']['EinheitText'] = implode( ' oder ' , $aEinht );
                     $aAufgabes['data'][$aIx]['antwort']['WerteText'] = $aAufgabe['antwort']['sollAntwort'] == $aAufgabe['antwort']['minAntwort'] ? $aAufgabe['antwort']['sollAntwort'] : 'zwischen ' . $aAufgabe['antwort']['minAntwort'] . ' und ' . $aAufgabe['antwort']['maxAntwort']  ;
            }
            return $aAufgabes;
    }



    /**
     * compressExame
     * for transport purpose, contains only neccessary variables
     * cuts out text and not used variables
     *
     * @param array $aChoosenAufgabes
     * @return array
     */
    Public function compressExame( $aChoosenAufgabes )
    {
            // flatternate aChoosenAufgabes
            $aExercises = [ 'sollZeit' => 0 , 'data' => [] ];

            foreach( $aChoosenAufgabes as $ix => $aFrage ){
                    
                    $aExercises['sollZeit'] += $aFrage['antwort']['Zeitvorgabe'];
                    
                    $aExercises['data'][$ix] =  'uid=' . $aFrage['uid'];
                    foreach( $this->aCompressed as $short => $longname ){
                        $aExercises['data'][$ix].= '+' . $short. '=' . $aFrage['antwort'][$longname];
                    }
                    
                    if( isset($aFrage['variables']) ){
                            $search['a'] = $this->aAufgabes[ $aFrage['uid'] ]->getAufgabe();
                            $search['h'] = $this->aAufgabes[ $aFrage['uid'] ]->getHilfetext();
                            $aExercises['data'][$ix].='+++';
                            foreach( $aFrage['variables'] as $variable => $content ){
                                    foreach( $search as $fulltext ){
                                            if( strpos( ' ' . $fulltext , '$' . $variable ) ) {
                                                    $aExercises['data'][$ix] .= $variable . '=' . $content . '+';
                                                    break;
                                            }
                                    }
                            }
                            $aExercises['data'][$ix] = rtrim( $aExercises['data'][$ix] , '+' );
                    }
            }
            
            return $aExercises;
    }


    /**
     * getExamesList
     *  
     *  used in Display-Plugin 'Calc' for
     *  - tryout view with 1x all exercises and result-area uncluding hint-text on bottom of each exercise.
     *  - exam view displays 1x  grouped exercises ...
     *  - ... AND forwarding to result-page (without hint-text) ...
     *  - ... AND PDF output OR back to tryout / exam
     *  
     *  used in Editor-Plugin 'Eced' for
     *  - printouts with multiple grouped or single pages AND result-page at the end (without hint-text)
     *
     * @param object $aAufgabes array of objects OR object as array of objects
     * @param array $aPdfSetttings optional
     * @return array
     */
    Public function getExamesList( $aAufgabes , array $aPdfSetttings = [ 'amount'=>1 , 'grouped'=>0 ] )
    {
			
			if( ( !is_object($aAufgabes) && !is_array($aAufgabes) ) || !count($aAufgabes) ) return [];
            
            foreach( $aAufgabes as $ix => $oAufgabe ){
                $this->aAufgabes[ $oAufgabe->getUid() ] = $oAufgabe;
			}
			
			$this->iAmount = isset($aPdfSetttings['amount']) && $aPdfSetttings['amount'] > 0 ? $aPdfSetttings['amount'] : 1;
			if( isset ( $aPdfSetttings['marker'] ) ) $this->aMarker = $aPdfSetttings['marker'];

			if( $aPdfSetttings['grouped'] ){
				$aExercisesUids = $this->getRandomizedExamesObjects_grouped();
			}else{
				$aExercisesUids = $this->getExamesObjects_separed();
			}

			if( !is_array($aExercisesUids) ) return [];
				
			$aEvaluatedExamen = [];
            foreach( $this->aAufgabes as $uid => $oAufgabe ){
                    if( !isset($aExercisesUids[$uid]) ) continue;
                    $aMultipleFormeln = $this->formulaUtility->getMultipleFormulasForExercise( $oAufgabe , count($aExercisesUids[$uid]) , false );
                    // $aMultipleFormeln counts from 1
                    $keylist = array_keys($aExercisesUids[$uid]); 
                    // $keylist counts from 0! 
                    foreach( $keylist as $idx => $examNr ) {
                        $counter = isset($aEvaluatedExamen[$examNr]) ? count($aEvaluatedExamen[$examNr])+1 : 1;
                        $aEvaluatedExamen[$examNr][$counter] = $aMultipleFormeln[$idx+1];
                        $aEvaluatedExamen[$examNr][$counter]['Nr'] = $counter;
                        $aEvaluatedExamen[$examNr][$counter]['uid'] = $uid;
                        $aEvaluatedExamen[$examNr][$counter]['obj'] = $oAufgabe;
                    }
            }
			ksort($aEvaluatedExamen);
			return  $aEvaluatedExamen ;

    }

    /**
     * getRandomizedExamesObjects_grouped
     *
     * @return array
     */
    Private function getRandomizedExamesObjects_grouped()
    {
				$aGroupedExercises = [];

				// group exercise by gruppe
				foreach( $this->aAufgabes as $oAufgabe ) {
					$uid = $oAufgabe->getUid();
					if( $this->aMarker == null || (isset($this->aMarker[$uid]) && !empty($this->aMarker[$uid])) ){
						$groupNr = $oAufgabe->getGruppe();
						if($groupNr) $aGroupedExercises[$groupNr][] = $uid;
					}
				}

				if( !count($aGroupedExercises) ) return $aGroupedExercises;
				
				if( $this->iAmount < 2 ) return $this->getRandomizedExamesObjects_randOneOfGroup($aGroupedExercises);
				
				return $this->getRandomizedExamesObjects_rotateOneOfGroup($aGroupedExercises);
				
    }

    /**
     * getRandomizedExamesObjects_rotateOneOfGroup
     *
     * @param array $aGroupedExercises
     * @return array
     */
    Private function getRandomizedExamesObjects_rotateOneOfGroup( $aGroupedExercises )
    {
				// collect a exercise from each group for each student
				$aExames = [];
                foreach($aGroupedExercises as $grp => $aUid){
                    for( $examNr=1 , $loops=1 ; $examNr <= $this->iAmount && $loops <= $this->iAmount ; ++$loops){
                        foreach($aUid as $uid) {
                            $aExames[$uid][$examNr] = $uid;
                            ++$examNr;
                            if($examNr > $this->iAmount) break;
                        }
                    }
                }
				return $aExames;
    }

    /**
     * getRandomizedExamesObjects_grouped
     *
     * @param array $aGroupedExercises
     * @return array
     */
    Private function getRandomizedExamesObjects_randOneOfGroup( $aGroupedExercises )
    {
				// collect a exercise from each group for one student
				$aExames = [];
				$examNr = 1;
                foreach($aGroupedExercises as $grp => $aUid){
                    // if more than one exercise in group then get a random exercise, else first element (0)
                    $elCount = count($aUid);
                    $randIdx = $elCount > 1 ? mt_rand( 0 , $elCount-1 ) : 0 ;
                    $uid = $aUid[$randIdx];
                    $aExames[$uid][$examNr] = $uid;
                }
				return $aExames;
    }

    /**
     * getExamesObjects_separed
     *
     * @return array
     */
    Private function getExamesObjects_separed()
    {
				$aExames = [];
				// collect every exercice for each student
                foreach( $this->aAufgabes as $oAufgabe ) {
                    $uid = $oAufgabe->getUid();
                    if( $this->aMarker == null || ( isset($this->aMarker[$uid]) && !empty($this->aMarker[$uid]) ) ){
                        for( $examNr=1 ; $examNr <= $this->iAmount ; ++$examNr) $aExames[$uid][$examNr] = $uid;
                    }
                }
				return $aExames;
    }


}

