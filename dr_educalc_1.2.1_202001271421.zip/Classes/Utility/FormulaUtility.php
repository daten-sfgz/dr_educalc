<?php
namespace Dr\DrEducalc\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class FormulaUtility
 * 
 */

class FormulaUtility {

    /**
     * errorMessage
     *
     * @var string
     */
    Public $errorMessage = '';

    /**
     * materialUtility
     *
     * @var \Dr\DrEducalc\Utility\MaterialUtility
     */
    protected $materialUtility = null;

    /**
     * localFormulas
     *
     * @var array
     */
    protected $localFormulas = [
            ' abrunden'     =>  ' floor' , 
            ' aufrunden'    =>  ' ceil' , 
            ' runden'       =>  ' round' , 
            ' quadratwurzel'=>  ' sqrt' , 
            ' exponentialfunktion'  =>  ' exp' , 
            ' potenz'       =>  ' pow' , 
            ' zufall'       =>  ' mt_rand' , 
            ' rest'         =>  ' fmod' 
    ];

    /**
     * appendWhitespace
     *
     * @var array
     */
    protected $appendWhitespace = [
            '(' =>  '( ' , 
            '<' =>  '< ' , 
            '>' =>  '> ' , 
            '%' =>  '% ' , 
            '*' =>  '* ' , 
            '-' =>  '- ' , 
            '+' =>  '+ ' , 
            '^' =>  '^ ' , 
            '/' =>  '/ ' , 
            '?' =>  '? ' , 
            '=' =>  '= ' , 
            ':' =>  ': ' , 
            ',' =>  ', '
    ];

    /**
     * constructor
     *
     * @return void
     */
    public function __construct()
    {
		$this->materialUtility = GeneralUtility::makeInstance('Dr\\DrEducalc\\Utility\\MaterialUtility');
    }

    /**
     * getMultipleFormulasForExercise
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @param int $iAmount default is 1
     * @param bool $realExecution true is save but slow
     * @return array
     */
    Public function getMultipleFormulasForExercise( \Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe , $iAmount = 1 , $realExecution = true )
    {
		$aSerialVariables = $realExecution ? $this->exec_getVariablesFromFormula( $aufgabe , $iAmount ) : $this->eval_getVariablesFromFormula( $aufgabe , $iAmount );
		return $this->applyVariablesToObject( $aufgabe , $aSerialVariables );
    }

    /**
     * exec_getVariablesFromFormula
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @param int $iAmount default is 1
     * @return array
     */
    Private function exec_getVariablesFromFormula( \Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe , $iAmount = 1 )
    {
		// get affored amount of material rows
		$aMat = $this->materialUtility->getRandomizedMaterial( $aufgabe , $iAmount );
		
		// prepare execution for formulas in formeln-field (formulas stays the same for each student)
            // replace german 'wenn' to 'if' and basis^exponent to pow(b,x)  basis^wurzel to pow(b,1/x)
		$strTranslatedFormulas = $this->translateFormulas( $aufgabe->getFormeln() );
            // pick the first matrerial, glue it togehter with formulas and check if unknown functions are embedded
		$formulaChecked = $this->checkFunctions( $strTranslatedFormulas , isset($aMat[1]) ? $aMat[1] : [] );
            // write the (checked) formulas as PHP code with echo statements
		$sInputFormulas = $this->prepStatementsForFormulas( $formulaChecked , true );
		
		// if there are enough material rows, then calculate with material, else calculate without material
		$aAssignText = [];
		if( count($aMat) == $iAmount ){
			// material rows changes for each student
			for( $i = 1 ; $i <= $iAmount ; ++$i ){
                // prepare execution for assignement in material row
				$sMaterialVariables = isset($aMat[$i]) ? $this->prepStatementsForMaterial( $aMat[$i] , true ) : '';
                // calculate with values from material-table, use for each execise a new row
				$aTmp = $this->exec_PreparedStatements( $sMaterialVariables . $sInputFormulas , 1 );
				$aAssignText[$i] = $aTmp[1];
			}
		}else{
			// calculate without material-table: use for all exercises the same formulas
			$aAssignText = $this->exec_PreparedStatements( $sInputFormulas , $iAmount );
		}

		$aSerialVariables = [];
		if( !count($aAssignText) ) return $aSerialVariables;
		
		foreach( $aAssignText as $i => $sCodelines ){
            $aSerialVariables[$i] = $this->exec_readVariablesFromResult( $sCodelines );
        }
		
		return $aSerialVariables;
	}

    /**
     * tryEvaluate
     *
     * @param str $phpText
     * @param int $iAmount default is 1x
     * @return array
     */
    Private function exec_PreparedStatements( $phpText , $iAmount = 1)
    {
		$aResults = [];
		if( empty($phpText) ) return [ 1 => '' ];
// 		if( empty($phpText) ) return [ 1 => 'Beispiel2Stellig = zufall( 10 , 99 )' ];
		
		$path = GeneralUtility::getFileAbsFileName( 'uploads/tx_dreducalc/' );
		$execFile = $path . 'prepareStatements.php';
		$resultFile = $path . 'resultOfStatements.txt';
		
		$commandstring = "<?PHP " . $phpText;
		// save the file
		file_put_contents( $execFile, $commandstring );
		@chmod( $execFile , 0777 );
		
		// run harmful file in background
		$oldErrorlevel = error_reporting(E_ALL);
		for( $i = 1 ; $i <= $iAmount ; ++$i ){
			exec( "php " . $execFile . " > " . $resultFile . " 2>&1" );
			if( file_exists( $resultFile ) ) {
				$aResults[$i] = file_get_contents( $resultFile );
			//	@unlink( $resultFile );
			}
		}
		error_reporting($oldErrorlevel);
		// delete the executed file
 	//	@unlink( $execFile );
		return $aResults;
			
	}

    /**
     * exec_readVariablesFromResult
     *
     * @param string $commandstring
     * @return array
     */
    Private function exec_readVariablesFromResult( $commandstring )
    {
		$lines = explode( "\n" , $commandstring );
		if( !count($lines) ) return [];
		$aVariables = [];
		foreach( $lines as $line ){
			if( strpos( ' ' . $line , 'Fatal error' ) ) {
				// render error warnings
				$aLin = explode( ":" , trim($line) );
				$aVariables['Fatal_error'] = trim(trim($aLin[1]),'"');
				
			}elseif( strpos( $line , '=' ) ){
				// render variables
				$aLin = explode( "=" , trim($line) );
				$aVariables[trim($aLin[0])] = trim(trim($aLin[1]),'"');
				
			}
		}
		return $aVariables;
	}

    /**
     * execValidateFormula
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @return boolean
     */
    Public function execValidateFormula( \Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe )
    {
            $formulaChecked = $this->getCheckedFormula( $aufgabe );
            if( strpos( ' ' . $formulaChecked , 'FEHLER' ) ) 
                return $this->errHandler( $formulaChecked , false  );
            
            // write the (checked) formulas as PHP code with echo statements
            $sInputFormulas = $this->prepStatementsForFormulas( $formulaChecked , true );
            
            // pick the first matrerial, glue it togehter with formulas and check if unknown functions are embedded
            $aMat = $this->materialUtility->getRandomizedMaterial( $aufgabe , 1 );
            $sMaterialVariables = count($aMat) && isset($aMat[1]) ? $this->prepStatementsForMaterial( $aMat[1] , true ) : '';
            
            $aStrings = $this->exec_PreparedStatements( $sMaterialVariables . $sInputFormulas , 1 );
            $aVariables = $this->exec_readVariablesFromResult( $aStrings[1] );
            
            if( isset($aVariables['Fatal_error']) ) 
                return $this->errHandler( $aVariables['Fatal_error'] , false  );
            
            foreach( $aVariables as $content ) {
                if( trim($content) == '' ) 
                    return $this->errHandler( 'Fehler in Formel' , false  );
            }
            
            return true;
	}

    /**
     * eval_getVariablesFromFormula
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @param int $iAmount default is 1
     * @return array
     */
    Private function eval_getVariablesFromFormula( \Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe , $iAmount = 1 )
    {
            $aSerialVariables = [];
            
            $formulaChecked = $this->getCheckedFormula( $aufgabe );
            
            if( strpos( ' ' . $formulaChecked , 'FEHLER' ) ) return $this->errHandler( $formulaChecked , []  );
		
            // write the (checked) formulas as PHP code without any echo statements
            $sInputFormulas = $this->prepStatementsForFormulas( $formulaChecked , false );
            
            // get material
            $aMat = $this->materialUtility->getRandomizedMaterial( $aufgabe , $iAmount );
            // material rows changes for each student
            for( $i = 1 ; $i <= $iAmount ; ++$i ){
                // prepare execution for assignement in material row
                $sMaterialVariables =  isset($aMat[$i]) ? $this->prepStatementsForMaterial( $aMat[$i] , false ) : '';
                $aSerialVariables[$i] = $this->eval_PreparedStatements( $sMaterialVariables . $sInputFormulas );
            }
            return $aSerialVariables;
	}

    /**
     * eval_PreparedStatements
     *
     * @param string $sPrepStatements
     * @return array
     */
    Private function eval_PreparedStatements( $sPrepStatements )
    {
            $aVariables = [];
            
            // eval the code 
            @eval( $sPrepStatements );
            
            // detect variables and assign them to an array
            $aLines = explode( "\n" , $sPrepStatements );
            
            foreach( $aLines as $Lix => $sCodeline ){
                $aOperands = explode( '=' , trim( $sCodeline ) );
                // remove the trailing dollar-char
                $variableName = trim( ltrim( trim($aOperands[0]) , '$' ) );
                // assign to array with double dollar $$ variableName
                if( !empty($variableName) ) $aVariables[ $variableName ] = $$variableName;
            }
            
            return $aVariables;
	}

    /**
     * applyVariablesToObject
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @param array $aSerialVariables
     * @return array
     */
    Private function applyVariablesToObject( \Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe , $aSerialVariables )
    {
		$aMultipleFormeln = [];
		
		if( !count($aSerialVariables) ) return $aMultipleFormeln;
		
		$aAufgabe = [
			'Formeln' => $aufgabe->getFormeln(),
			'Antwort' => $aufgabe->getAntwort() , 
			'Einheiten' =>  $aufgabe->getEinheiten() , 
			'Zeitvorgabe' =>  $aufgabe->getZeitvorgabe() , 
			'Punkte' =>  $aufgabe->getPunkte() , 
			'Toleranzwert' =>  $aufgabe->getToleranzwert() , 
			'Toleranzmin' =>  $aufgabe->getToleranzmin() , 
			'Toleranzmax' =>  $aufgabe->getToleranzmax() ,
			'Aufgabe' => $aufgabe->getAufgabe() , 
			'Titel' => $aufgabe->getTitel() , 
			'Hilfetext'=> $aufgabe->getHilfetext()
		];
		
		foreach( $aSerialVariables as $i => $aVariables ){
			
			// prepare variables for replacement
			$aReplacements = $this->getArrayKeysSortedAndNumberFormatted( $aVariables );
			
			// do replacement on text-fields
			$aAufgabetext = $this->replacePatternByValues( $aAufgabe['Aufgabe'] , $aReplacements );
			$aHilfetext = $this->replacePatternByValues( $aAufgabe['Hilfetext'] , $aReplacements );
			
			$sollAntwort = is_numeric($aVariables[ $aAufgabe['Antwort'] ]) ? $aVariables[ $aAufgabe['Antwort'] ] : 0;
            
            $abweichung = $this->getDifferenceFromTolerance( $sollAntwort , $aAufgabe['Toleranzwert'] , $aAufgabe['Toleranzmin'] , $aAufgabe['Toleranzmax'] );
            
            $minAntwort = $sollAntwort - $abweichung;
            $maxAntwort = $sollAntwort + $abweichung;
			
			$sEinheitText = '&raquo;' . implode( '&laquo; oder &raquo;' , explode( ',' , $aAufgabe['Einheiten'] ) ) . '&laquo;';
            $sWerteText = empty($abweichung) ? $sollAntwort : 'zwischen ' . $minAntwort . ' und ' . $maxAntwort  ;
			
			// pack informations in an array
			$aMultipleFormeln[$i] =  [
				'text' => [ 
					'Aufgabe' => $aAufgabetext , 
					'Hilfetext' =>  $aHilfetext ,
					'Titel' => $aAufgabe['Titel']
				] ,
				'antwort' => [ 
					'sollAntwort' => $sollAntwort ,
					'minAntwort' => $minAntwort ,
					'maxAntwort' => $maxAntwort ,
					'WerteText' => $sWerteText ,
					'Einheiten' =>  $aAufgabe['Einheiten'] ,  
					'EinheitText' => $sEinheitText ,  
					'Zeitvorgabe' =>  $aAufgabe['Zeitvorgabe'] ,
					'Punkte' =>  $aAufgabe['Punkte']  
				] ,
				'variables' =>  $aVariables
			];
		}
		return $aMultipleFormeln;
    }

    /**
     * getArrayKeysSortedAndNumberFormatted
     * used by this class and by exerciseUtility while decompression
     *
     * @param array  $aVariables
     * @return array
     */
    Public function getArrayKeysSortedAndNumberFormatted($aVariables)
    {
			$aReplacements = [];
			$aKeys = $this->getArrayKeysSortedByKeyLength($aVariables);
			// resort array
			foreach($aKeys as $idx => $key ) {
				if( isset($aVariables[$key]) ) $aReplacements[$key] = $this->numberFormat( $aVariables[$key] );
			}
			return $aReplacements;
    }

    /**
     * getArrayKeysSortedByKeyLength
     *
     * @param array  $aVariables
     * @return array
     */
    Private function getArrayKeysSortedByKeyLength($aVariables)
    {
		$aKeylengths = [];
		$aKeys = [];
		if( !is_array($aVariables) || !count($aVariables) ) return $aVariables;
		foreach( array_keys( $aVariables ) as $key ){
			if( trim($key) == '' ) continue;
			$aKeylengths[$key] = strlen( $key );
		}
		if( !count($aKeylengths) ) return $aVariables;
		
		arsort($aKeylengths);
		foreach( array_keys( $aKeylengths ) as $key ){
			$aKeys[] = $key;
		}
		return $aKeys;
    }
	
    /**
     * numberFormat
     *
     * @param string $number
     * @return string
     */
	Private function numberFormat( $number ) {
 	      if( !is_numeric($number) ) return $number;
 	      if( $number < 1000 ) return $number;
 	      
	      $nachkomma = round($number - floor($number) , 12);
	      $nachkommastellen = strlen($nachkomma)<3 ? 0 : strlen($nachkomma)-2 ;
	      return number_format( $number , $nachkommastellen , '.' , "'" );
	}

    /**
     * replacePatternByValues
     *
     * @param string $sText
     * @param array  $aReplacements
     * @return array
     */
    Private function replacePatternByValues( $sText , $aReplacements )
    {
		if( !is_array($aReplacements) || !count($aReplacements) ) return $sText;
		foreach($aReplacements as $pattern => $value ) $sText = str_replace( '$' . $pattern , $value , $sText );
		return $sText;
    }

    /**
     * getDifferenceFromTolerance
     *
     * @param int $sollAntwort
     * @param str $tolValue
     * @param int $tolMin
     * @param int $tolMax
     * @return int
     */
    private function getDifferenceFromTolerance( $sollAntwort , $tolValue , $tolMin , $tolMax )
    {
			// calculate maximum and minimum values as valid responses
            $abweichung = 0; // no value given
			$isProcentual = strpos( $tolValue , '%' );
			$procentVal = str_replace('%','',$tolValue);
			if( $isProcentual &&  is_numeric($procentVal) ){ // as percent value %
                $abweichungAusPrz = $sollAntwort / 100 * $procentVal;
                if( empty( $tolMin ) ) $tolMin = 0;
                if( empty( $tolMax ) ) $tolMax = 0;
                if( $abweichungAusPrz < $tolMin ){
                    $abweichung = $tolMin;
                }elseif( $abweichungAusPrz > $tolMax && !empty($tolMax)  ){
                    $abweichung = $tolMax;
                }else{
                    $abweichung = $abweichungAusPrz;
                }
                
			}elseif( $tolValue ){ // absolute value
                $abweichung = $tolValue;
                
			}
			return $abweichung;
	}


    /**
     * getCheckedFormula
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @return string OR empty string OR errormessage FEHLER_unbekannte_Funktion
     */
    Private function getCheckedFormula( \Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe )
    {
            // replace german 'wenn' to 'if' and basis^exponent to pow(b,x)  basis^wurzel to pow(b,1/x)
            $multiLineCommandString = $aufgabe->getFormeln();
            $strTranslatedFormulas = $this->translateFormulas( $multiLineCommandString );
            // pick the first matrerial, glue it togehter with formulas and check if unknown functions are embedded
            $aMat = $this->materialUtility->getRandomizedMaterial( $aufgabe , 1 );
            // check formula
            $formulaChecked = $this->checkFunctions( $strTranslatedFormulas , isset($aMat[1]) ? $aMat[1] : [] );
            return $formulaChecked;
	}
    
    /**
     * translateFormulas
     *
     * @param str $sFormulas
     * @return str
     */
	Private function translateFormulas($sFormulas) {

        $sFormulas = str_replace( array_keys($this->appendWhitespace) , $this->appendWhitespace , $sFormulas );
        
        $sFormulas = $this->translate_replaceAfterCharInTextarea( array_keys($this->localFormulas) , $this->localFormulas , $sFormulas , '=' , "\n" );

		$aFormularows = explode( "\n" , $sFormulas );
		$newRows = [];
		
		$aSanitize = [ ';' => ',' , ' Pi ' => ' pi() ' , ' pi ' => ' pi() ' , ' pi)' => ' pi() ) ' ];
		
		foreach( $aFormularows as $ix => $row ){
                
                // replace the semicolon and pi with pi() to prevent errors!
                $row = str_replace( array_keys($aSanitize) , $aSanitize , $row );
			
                $firstOpenBrace = strpos( $row , '(' );
                $firstClosBrace = strpos( $row , ')' );
                
                if( !$firstOpenBrace && !$firstClosBrace ){
                    $newRows[$ix] = $row;
                }elseif( !$firstOpenBrace || !$firstClosBrace || $firstClosBrace < $firstOpenBrace ){
                    $newRows[$ix] = 'Fehler = ' .  $row;
                }else{
                    $newRows[$ix] = $this->translate_replaceWennStatementInRow( $row ) ;
                    $newRows[$ix] = $this->translate_replaceWurzelStatementInRow( $newRows[$ix] ) ;
                }
		}

		return implode( "\n" , $newRows );;
    }
    
    /**
     * translate_replaceWurzelStatementInRow
     *
     * @param str $row
     * @return str
     */
	Private function translate_replaceWurzelStatementInRow( $row ) 
	{
			// replace ALL "wurzel( radikant , wurzelexponent )" with "pow( radikand , 1 / wurzelexponent )"
			$newRow = $row;
			$varLength = strpos( $row , '=' );
			if( !$varLength ) return $newRow;
			
			// find position of closing brace starting after the first 'wurzel'
			$firstIfWenn = strpos( $row , 'wurzel' , $varLength );
			if( !$firstIfWenn )  return $newRow;
			// find first open brace
			$firstOpenBrace = strpos( $row , '(' , $firstIfWenn );
			if( !$firstOpenBrace )  return $newRow;
			$lastPosition = strlen($row);

			// detect next comma
			$funcSeparer = ',';
			if( !strpos( $newRow , $funcSeparer ) ) {
                return $newRow;
			}

			for( $cPos = $firstOpenBrace + 1 , $openBrackets = 1 ; $cPos < $lastPosition && $openBrackets > 0 ; ++$cPos){
				
				$charOnPos = substr( $row , $cPos , 1 );
				
				if( $charOnPos == '(' ){ $openBrackets += 1; }elseif( $charOnPos == ')' ){ $openBrackets -=1 ; }
				if( $openBrackets > 1 ) continue; // we are in a 'inner' function, continue until next closing bracket
				if( $openBrackets == 0 ) break;// finished for this 'wurzel'

				if( $charOnPos == $funcSeparer ){
					$endOfFunc = strpos( $newRow , ')' , $cPos + 1 );// position of next closing bracket from first char
					$lengthOfTail = $endOfFunc - ($cPos + 1);
					$exponent = trim( substr( $newRow , $cPos + 1 , $lengthOfTail ) );
					$tailingText = substr( $newRow , $endOfFunc );
					$newRow = str_replace( 'wurzel(' , 'pow(' , substr( $newRow , 0 , $cPos ) ) . ', 1 / (' . $exponent .') ' . $tailingText;
					// now the replacement has finished
					break;
				}
				
			}
			return strtolower($row) == strtolower($newRow) ? $newRow : $this->translate_replaceWurzelStatementInRow( $newRow );
			
    }
    
    /**
     * translate_replaceWennStatementInRow
     *
     * @param str $row
     * @return str
     */
	Private function translate_replaceWennStatementInRow( $row ) 
	{
			// replace ALL "wenn( c , t , e )" with "( c ? t : e )"
			// and also nested: wenn( c , wenn(c1,t1,e1) , wenn(c2,t2, wenn(c3,t3,(1*e3) ) ) )
			$newRow = $row;
			$varLength = strpos( $row , '=' );
			if( !$varLength ) return $newRow;
			
			// find position of closing brace starting after the first 'wenn'
			$firstIfWenn = strpos( $row , 'wenn' , $varLength );
			if( !$firstIfWenn )  return $newRow;
			// find first open brace
			$firstOpenBrace = strpos( $row , '(' , $firstIfWenn );
			if( !$firstOpenBrace )  return $newRow;
			$lastPosition = strlen($row);
			
			// detect semicolon or comma
			$funcSeparer = ',';
			
			for( $cPos = $firstOpenBrace + 1 , $openBrackets = 1 , $commas = 0 ; $cPos < $lastPosition && $openBrackets > 0 ; ++$cPos){
				
				$charOnPos = substr( $row , $cPos , 1 );
				
				if( $charOnPos == '(' ){ $openBrackets += 1; }elseif( $charOnPos == ')' ){ $openBrackets -=1 ; }
				if( $openBrackets > 1 ) continue; // if we are in a 'inner' function then continue until next closing bracket
				if( $openBrackets == 0 ) continue;// finished for this 'wenn'
				
				if( $charOnPos == $funcSeparer ){
					if( $commas == 0 ){
						$newRow = substr( $newRow , 0 , $cPos ) . '?' . substr( $newRow , $cPos+1 ) ;
						++$commas;
					}elseif( $commas == 1 ){
						// now the replacement has finished
						$newRow = substr( $newRow , 0 , $cPos ) . ':' . substr( $newRow , $cPos+1 ) ;
						// delete the 'wenn'
						$newRow = substr( $newRow , 0 , $firstIfWenn ) . substr( $newRow , $firstIfWenn+4 );
					}
				}
			}
			
			return strtolower($row) == strtolower($newRow) ? $newRow : $this->translate_replaceWennStatementInRow( $newRow );
    }
    
    /**
     * translate_replaceAfterCharInTextarea
     *  replaces the string after a specified char (like '=') in each line of wrapped (or non-wrapped) text
     *
     * @param str $strTextarea
     * @param array $search
     * @param array $replace
     * @param str $split
     * @param str $lineEnd
     * @return str
     */
	Private function translate_replaceAfterCharInTextarea( $search , $replace , $strTextarea , $split = '=' , $lineEnd = "\n" ) {
		
		$aTextrows = explode( $lineEnd , $strTextarea );
		if( !count($aTextrows) ) $aTextrows = [ $strTextarea ];
		
		$strReplacedText = '';
		foreach( $aTextrows as $row ){
				$aParts = explode( $split , $row ); 
				if( 2 == count($aParts) ){
                    // make shure there is exactly one leading space-char
                    $rawText = ' ' . ltrim( $aParts[1] , ' ' );
					$strReplacedText .= $aParts[0] . $split . str_replace( $search , $replace , $rawText );
					
				}else{ // error: not 2 parts or splitter 'equal' missing
					$strReplacedText .=  $row ;
				}
				$strReplacedText .= $lineEnd ;
		}
		
		return $strReplacedText;
    }
    
    /**
     * checkFunctions
     * - checks if unknown functions are embedded
     * - replaces all allowed chars and words with empty char - the remaining string is not allowed
     * - on success it returns the formulas from input 
     * - otherwise  it returns the string: FEHLER_unbekannte_Funktion
     *
     * @param str $sFormulas
     * @param array $aMatrow optional
     * @return str
     */
	Private function checkFunctions( $sFormulas , $aMatrow = [] ) {
		$aFormulas = explode( "\n" , $sFormulas );
		if( !count($aFormulas) ) return false;
		
		$aVariables = [];
		foreach( $aFormulas as $line ){
			$cleanline = ltrim( rtrim( trim($line) , ';' ) , '$' );
			if( !strpos( $cleanline , '=' ) ) continue;
			$aTestCode = explode( '=' , $cleanline );
			$aVariables[] = trim($aTestCode[0]);
		}
		// allowed variables
		$formVariables = count($aVariables) ? '|' . implode( '|' , $aVariables ) : '';
		$matVariables = count($aMatrow) ? '|' . implode( '|' , array_keys( $aMatrow ) ) : '';
	    // Allowed functions
	    $functions = 'pi|sin|cos|tan|acos|asin|atan|exp|log|fmod|deg2rad|rad2deg|sqrt|pow|abs|intval|ceil|floor|round|mt_rand|rand';
		$unsortedSearch = array_flip( explode( '|' , $functions . $matVariables . $formVariables ) );
	    $sortedWords = implode( '|' , $this->getArrayKeysSortedByKeyLength( $unsortedSearch ) );
	    
	    
	    // Allowed math operators
	    $operators = '<|>|%|*|/|^|+|-|,| |?|(|)|=|:|"' . "|'";
	    // Allowed numbers
	    $numbers = '0|1|2|3|4|5|6|7|8|9|.|$';
	    
		$search = explode( '|' , $sortedWords . '|' . $operators . '|' . $numbers );
		
		// replace all allowed chars and words with empty char - the remaining string is not allowed
		$restOfExec = trim( str_replace( $search , '' , $sFormulas ) );

        // On success return the formulas from input, otherwise the string: FEHLER_unbekannte_Funktion
		return strlen($restOfExec) ? 'FEHLER_unbekannte_Funktion = "' . $restOfExec . '"'  : $sFormulas;
    }


    /**
     * prepStatementsForMaterial
     *
     * @param array $aMat
     * @param bool $echoOutput optional, default is to echo the output
     * @return string
     */
    Private function prepStatementsForMaterial($aMat , $echoOutput = true )
    {
		if( ( !is_array($aMat) && !is_object($aMat) ) || !count($aMat) ) return false;
		
		$sMaterialVariables = "";
		foreach( $aMat as $var => $val ) {
			if( !is_numeric($val) ) {
				$val = '"' . trim(trim($val,'"'),"'") . '"';
			}
			$sMaterialVariables .= '$' . $var . ' = ' . $val . ";\n"; 
 			if( $echoOutput ) $sMaterialVariables .= 'echo \'' . $var . ' = ' . $val . '\' . "\n"' . ";\n";
		}
		return $sMaterialVariables;
    }


    /**
     * prepStatementsForFormulas
     *
     * @param str $text
     * @param bool $echoOutput optional, default is to echo the output
     * @return string
     */
    Private function prepStatementsForFormulas($text , $echoOutput = true )
    {
		$sInputFormulas = "";
		$aFormulas = explode( "\n" , $text );
		if( !count($aFormulas) ) return false;
		
		foreach( $aFormulas as $line ){
			$cleanline = ltrim( rtrim( trim($line) , ';' ) , '$' );
			if( !strpos( $cleanline , '=' ) ) continue;
			$aTestCode = explode( '=' , $cleanline );
			$variablename = trim($aTestCode[0]);
			$formula = trim($aTestCode[1]);
			if( is_numeric($variablename) || $variablename == '' || $formula == '' ) continue;
			$sInputFormulas .= '$' . $cleanline . ";\n";
			if( $echoOutput ) $sInputFormulas .= 'echo "' . $variablename . ' = " . $' . $variablename .' . "\n"' . ";\n";
		}
		return $sInputFormulas;
    }

    /**
     * errHandler
     *
     * @param string $errorMessage
     * @param string $returnValue
     * @return string OR empty string OR errormessage FEHLER_unbekannte_Funktion
     */
    Private function errHandler( $errorMessage , $returnValue  )
    {
            $this->errorMessage = trim( $this->errorMessage . ' ' . str_replace( 'FEHLER_unbekannte_Funktion =' , 'Unbekannte Funktion:' , $errorMessage ) ) ;
            return $returnValue;
    }

}
