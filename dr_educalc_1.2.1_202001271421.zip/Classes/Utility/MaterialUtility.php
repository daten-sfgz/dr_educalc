<?php
namespace Dr\DrEducalc\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class MaterialUtility
 * 
 */

class MaterialUtility {

    /**
     * materialRepository
     *
     * @var \Dr\DrEducalc\Domain\Repository\MaterialRepository
     */
    protected $materialRepository = null;

    /**
     * constructor
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * getRandomizedMaterial
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @param int $iAmount default is 1
     * @return array  return2dimArr[ iTableRow => [ strFieldname => strContent ] ]
     */
    Public function getRandomizedMaterial(\Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe , $iAmount = 1 )
    {
		$aMaterial = $this->getMaterial($aufgabe);
		$aMat = $this->randomizeMaterial( $aMaterial , $iAmount );
		return $aMat ;

    }

    /**
     * getMaterial
     *
     * @param Dr\DrEducalc\Domain\Model\Aufgabe
     * @return array  return2dimArr[ iTableRow => [ strFieldname => strContent ] ]
     */
    Public function getMaterial(\Dr\DrEducalc\Domain\Model\Aufgabe $aufgabe)
    {
			$aMaterial = [];
			$dbTable = [];
			$aMatTables = $aufgabe->getAufMat();
			if( !$aMatTables || !count($aMatTables) ) return $aMaterial;

			$tix = 0;
			foreach( $aMatTables as $objMat ){
				$sTb = trim($objMat->getTabelle());
				if( !$sTb || empty($sTb) ) continue;
				$aTb = explode( "\n" , $sTb );
				if( !count($aTb) ) continue;
				$strFelder = $objMat->getFelder();
				$dbTable[$tix]['uid'] = $objMat->getUid();
				$dbTable[$tix]['fieldnames'] = explode( ';' , $strFelder );
				$dbTable[$tix]['body'] = $aTb;
				foreach($aTb as $ix => $row ){
					$aRow = explode( ';' , $row );
					// make shure we have enough fieldnames
					if( count($aRow) - count($dbTable[$tix]['fieldnames']) > 0 ) for( $fieldIdx = count($dbTable[$tix]['fieldnames']) ; $fieldIdx <= count($aRow)-1 ; ++$fieldIdx ){ $dbTable[$tix]['fieldnames'][] = chr(65+$fieldIdx); }
				}
				++$tix;
			}

			$aConcTabs = $this->concatTables( $dbTable );

			return $aConcTabs;
    }

    /**
     * concatTables
     *
     * @param array $dbTable
     * @return array  return2dimArr[ iTableRow => [ strFieldname => strContent ] ]
     */
    Private function concatTables( $dbTable )
    {
			// decide whether to concat tables vertical by rows (same fieldnames) or horizontal by columns (different fieldnames)
			$appendTo = [];
			$aTablesApppendedRows = [];
			$aRowcounter = [];
			$aOldFields = [];
			$aNewFields = [];
			$aTablesConcatenatedColumns = [];
			$aConcatenatedTables = [];

			for( $tix = 0 ; $tix <= count($dbTable)-1 ; ++$tix ){
				for ( $compareTix = $tix+1 ; $compareTix <= count($dbTable)-1 ; ++$compareTix){
					$outerFlds = $dbTable[$tix]['fieldnames'];
					$innerFlds = $dbTable[$compareTix]['fieldnames'];
					sort($outerFlds);
					sort($innerFlds);
					$isTheSame = implode( ';' , $innerFlds ) == implode( ';' , $outerFlds ) ? 1 : 0 ;
					$appendTo[$tix][$compareTix] = $isTheSame;
				}
			}
			
			// append tablerows to the first of all equal tables
			if( count($appendTo) ){ 
				foreach( $appendTo as $tix => $aC ){
					if( isset( $done[$tix]) ) continue;
					$appendArr = [];
					foreach( $aC as $compareTix => $isTheSame){
						if( $isTheSame ) {
							$done[$tix] = $dbTable[$tix]['uid'];
							$done[$compareTix] = $dbTable[$compareTix]['uid'];
							$appendArr[$compareTix] = $dbTable[$compareTix]['uid'] . ' ' . implode( ',' , $dbTable[$compareTix]['fieldnames']) . ' +' . count($dbTable[$compareTix]['body']);
						}
					}
 					if( !count($appendArr) ) continue;
					
					// collect appended tables
					$aTablesApppendedRows[$tix] = $appendArr;
					// collect first table (where others get appended on)
					$aTablesApppendedRows[$tix][$tix] = $dbTable[$tix]['uid'] . ' ' . implode( ',' , $dbTable[$tix]['fieldnames']) . ' +' .  count($dbTable[$tix]['body']) ;
					// really apend rows to first table and delete appended tables
					foreach( array_keys( $appendArr ) as $compareTix ){
						$iFields = array_flip( $dbTable[$compareTix]['fieldnames'] );
						foreach( $dbTable[$compareTix]['body'] as $rix => $innerRow ) {
							$oldRow = explode( ';' , trim($innerRow) );
							$newRow = [];
							foreach( $dbTable[$tix]['fieldnames'] as $outerFldIx => $outerField ) {
								$newRow[ $outerFldIx ] = trim( $oldRow[ $iFields[$outerField] ] );
							}
							$dbTable[$tix]['body'][] = implode( ';' , $newRow );
						}
						unset($dbTable[$compareTix]);
					}
				}
			}
			
			// prepare concatenation
			// set appended tables to the right order (longest first)
			if( count($aTablesApppendedRows) ) {
				foreach( array_keys( $aTablesApppendedRows ) as $tix ){
					$aRowcounter[$tix] = count($dbTable[$tix]['body']);
				}
			}
			// set single tables to the right order (longest first)
			foreach( $dbTable as $tix => $tArr ){
				//if( isset($done[$tix]) ) continue;
				$aRowcounter[$tix] = count($dbTable[$tix]['body']);
			}
			arsort($aRowcounter);
			
			// detect doublettes in fieldnames and set rename-array
			$newPos = 0;
			foreach( $aRowcounter as $tix => $sum ){
				foreach( $dbTable[$tix]['fieldnames'] as $oPos => $origNam ) {
					$newNam = $origNam . ( isset($aNewFields[ $origNam ]) ? $tix+1 : '');
					$aNewFields[ $newNam ] = [ 'tid' => $dbTable[$tix]['uid'] , 'oldPos'=>$oPos , 'newPos'=>$newPos , 'oldName'=>$origNam , 'newName'=>$newNam  ];
					$aOldFields[ $dbTable[$tix]['uid'] ][ $oPos ] = $aNewFields[ $newNam ];
					$newPos += 1;
				}
			}
			
			// 1. detect the longest table, 2. fill other tables to same length and 3. concatenate fields of other tables
			$maxRows = max($aRowcounter);
			foreach( $aRowcounter as $tix => $sum ){
				$add = $maxRows-$sum;
				$iterations = ceil( $add / count($dbTable[$tix]['body']) );
				$oldRows = $dbTable[$tix]['body'];
				if( $add ){ // if add == 0 this is the longest table - do nothing
					// 2. fill all other tables up to same length
					for( $i = 1 , $a = 1 ; $i <= $iterations && $a <= $add ; ++$i ){
						foreach( $oldRows as $tableIx => $tableRow ){
							$dbTable[$tix]['body'][] = $tableRow;
							++$a;
							if($a > $add) break;
						}
					}
				}
				
				$aTablesConcatenatedColumns[ $dbTable[$tix]['uid'] ] = $dbTable[$tix]['body'];
			}
			
			// 3. concatenate fields of all remained tables
			
			for( $rowNr = 0 ; $rowNr < $maxRows ; ++$rowNr ){
				foreach( $aTablesConcatenatedColumns as $tix => $aTableBody ){
					$aRow = explode( ';' , $aTableBody[$rowNr] );
					foreach( $aRow as $fieldIndex => $cellcontent ){
						$fldName = $aOldFields[$tix][$fieldIndex]['newName'];
						$aConcatenatedTables[$rowNr][ $fldName ] = trim($cellcontent);
					}
				}
			}

			return $aConcatenatedTables;
    }

    /**
     * randomizeMaterial
     *
     * @param array $aMat
     * @param int $iAmount default is 1
     * @return array  return2dimArr[ iTableRow => [ strFieldname => strContent ] ]
     */
    Private function randomizeMaterial( $aMat , $iAmount = 1 )
    {
		if( !is_array($aMat) ) return [];
		if( !count($aMat) ) return [];
		
		// redim material if not enough rows
		if( count($aMat) < $iAmount ){
			$diff = $iAmount - count($aMat) ;
			for( $appended = 1 , $loops = 1 ; $appended <= $diff && $loops <= $diff ; ++$loops ){ 
				foreach( $aMat as $mIx => $matRow ) {
					$aMat[] = $matRow;
					++$appended;
					if($appended > $diff) break;
				}
			}
		}
		
		// collect given amount of random rows
		$aOutMat = [];
		for( $loops = 1 ; $loops <= $iAmount ; ++$loops ){
			// create a fresh array with upcounting numeric keys
			$aMatKeys = array_keys($aMat) ;
			// pick one value from this array
			$zufallszahl = mt_rand( 0 , count($aMatKeys)-1 ) ;
			// detect the key of this material row
			$origKey = $aMatKeys[$zufallszahl] ;
			// store the material-row in a new array and delete the original
			$aOutMat[$loops] = $aMat[$origKey] ;
			unset($aMat[$origKey]);
		}

		return $aOutMat ;
    }

}
