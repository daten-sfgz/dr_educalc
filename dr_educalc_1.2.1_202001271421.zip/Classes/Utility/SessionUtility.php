<?php
namespace Dr\DrEducalc\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class SessionUtility
 * 
 */

class SessionUtility {

	/**
	* storageKey
	*
	* @var string
	*/
	Protected $storageKey = 'DrEducalc';

    /**
     * getData
     *
     * @param string $piUid optional default is empty
     * @return void
     */
    public function getData( $piUid = '' )
    {
		$settings_useroptions = [];
		$userObj = $GLOBALS['TSFE']->fe_user;
		if( $userObj ){
			$settings_useroptions = $userObj->getKey('ses', $this->storageKey );
		}
		if( $piUid ){
			return isset($settings_useroptions[$piUid]) ? $settings_useroptions[$piUid] : '' ;
		}
		return $settings_useroptions ;
		
    }

    /**
     * resetData
     *
     * @param int $piUid
     * @return void
     */
    public function resetData( $piUid = 0 )
    {
		$userObj = $GLOBALS['TSFE']->fe_user;
		if( $userObj ){
				if( $piUid ){
					$settings_useroptions = $userObj->getKey('ses', $this->storageKey );
					$settings_useroptions[$piUid] = [];
				}else{
					$settings_useroptions = [];
				}
				$userObj->setKey("ses","DrEducalc", $settings_useroptions );
				$userObj->sesData_change = true;
				$userObj->storeSessionData();
		}
    }

    /**
     * setData
     *
     * @param array $aData
     * @return void
     */
    public function setData( $aData )
    {
		$userObj = $GLOBALS['TSFE']->fe_user;
		if( $userObj ){
			$settings_useroptions = $userObj->getKey('ses', $this->storageKey );
			if( is_array($aData) && count($aData) ){
				foreach( $aData as $piUid => $value ){
					if( is_array($value) ){
						foreach( $value as $field => $cnt ){
							if( is_array($cnt) ){
								foreach( $cnt as $pos => $chr ) $settings_useroptions[$piUid][$field][$pos] = $chr;
							}else{
								$settings_useroptions[$piUid][$field] = $cnt;
							}
						}
					}else{
						$settings_useroptions[$piUid] = $value;
					}
				}
				$userObj->setKey("ses","DrEducalc", $settings_useroptions);
				$userObj->sesData_change = true;
				$userObj->storeSessionData();
			}
		}
    }

    /**
     * loop_setData
     *
     * @param array $aSettings
     * @param array $aAdditionalSettings
     * @return array
     */
    private function loop_setData( $aSettings , $aAdditionalSettings )
    {
            if( is_array($aAdditionalSettings) ){
                foreach( $aAdditionalSettings as $key => $subSetting ) $aSettings[$key] = $this->loop_setData( $aSettings[$key] , $subSetting );
            }else{
                $aSettings = $aAdditionalSettings;
            }
            return $aSettings;
    }

}
