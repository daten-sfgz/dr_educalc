<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe',
        'label' => 'titel',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
        'enablecolumns' => [
            'pid' => 'pid',
            'disabled' => 'hidden',
        ],
        'searchFields' => 'titel,aufgabe,antwort,toleranzwert,toleranzmin,toleranzmax,einheiten,zeitvorgabe,punkte,formeln,hilfetext,auf_mat,auf_kat',
        'iconfile' => 'EXT:dr_educalc/Resources/Public/Icons/tx_dreducalc_domain_model_aufgabe.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'hidden, versteckt, titel, aufgabe, antwort, toleranzwert, toleranzmin, toleranzmax, einheiten, zeitvorgabe, punkte, formeln, hilfetext, auf_mat, auf_kat',
    ],
    'types' => [
        '1' => ['showitem' => 'hidden, versteckt, titel, aufgabe, antwort, toleranzwert, toleranzmin, toleranzmax, einheiten, zeitvorgabe, punkte, formeln, hilfetext, auf_mat, auf_kat'],
    ],
    'columns' => [
		'pid' => [
			'config' => [
				'type' => 'passthrough'
			],
		],        
		'sorting' => [
			'config' => [
				'type' => 'passthrough'
			],
		],        
        'gruppe' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.gruppe',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'hidden' => [
            'exclude' => true,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],
        'versteckt' => [
            'exclude' => false,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],

        'titel' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.titel',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'aufgabe' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.aufgabe',
            'config' => [
                'type' => 'text',
                'enableRichtext' => true,
                'richtextConfiguration' => 'default',
                'fieldControl' => [
                    'fullScreenRichtext' => [
                        'disabled' => false,
                    ],
                ],
                'cols' => 40,
                'rows' => 15,
                'eval' => 'trim',
            ],
            
        ],
        'antwort' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.antwort',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'toleranzwert' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.toleranzwert',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'toleranzmin' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.toleranzmin',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'toleranzmax' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.toleranzmax',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'einheiten' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.einheiten',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'zeitvorgabe' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.zeitvorgabe',
            'config' => [
                'type' => 'input',
                'size' => 4,
                'eval' => 'int'
            ]
        ],
        'punkte' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.punkte',
            'config' => [
                'type' => 'input',
                'size' => 4,
                'eval' => 'int'
            ]
        ],
        'formeln' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.formeln',
            'config' => [
                'type' => 'text',
                'cols' => 40,
                'rows' => 15,
                'eval' => 'trim'
            ]
        ],
        'hilfetext' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.hilfetext',
            'config' => [
                'type' => 'text',
                'enableRichtext' => true,
                'richtextConfiguration' => 'default',
                'fieldControl' => [
                    'fullScreenRichtext' => [
                        'disabled' => false,
                    ],
                ],
                'cols' => 40,
                'rows' => 15,
                'eval' => 'trim',
            ],
            
        ],
        'auf_mat' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.auf_mat',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectMultipleSideBySide',
                'foreign_table' => 'tx_dreducalc_domain_model_material',
                'MM' => 'tx_dreducalc_aufgabe_material_mm',
                'size' => 10,
                'autoSizeMax' => 30,
                'maxitems' => 9999,
                'multiple' => 0,
                'fieldControl' => [
                    'editPopup' => [
                        'disabled' => false,
                    ],
                    'addRecord' => [
                        'disabled' => false,
                    ],
                    'listModule' => [
                        'disabled' => true,
                    ],
                ],
            ],
            
        ],
        'auf_kat' => [
            'exclude' => true,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_aufgabe.auf_kat',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectMultipleSideBySide',
                'foreign_table' => 'tx_dreducalc_domain_model_kategorie',
                'MM' => 'tx_dreducalc_aufgabe_kategorie_mm',
                'size' => 10,
                'autoSizeMax' => 30,
                'maxitems' => 9999,
                'multiple' => 0,
                'fieldControl' => [
                    'editPopup' => [
                        'disabled' => false,
                    ],
                    'addRecord' => [
                        'disabled' => false,
                    ],
                    'listModule' => [
                        'disabled' => true,
                    ],
                ],
            ],
            
        ],
    
    ],
];
