<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_kategorie',
        'label' => 'kategorie',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
        'enablecolumns' => [
            'pid' => 'pid',
            'disabled' => 'hidden',
        ],
        'searchFields' => 'kategorie',
        'iconfile' => 'EXT:dr_educalc/Resources/Public/Icons/tx_dreducalc_domain_model_kategorie.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'hidden, versteckt, kategorie',
    ],
    'types' => [
        '1' => ['showitem' => 'hidden, versteckt, kategorie'],
    ],
    'columns' => [
		'pid' => [
			'config' => [
				'type' => 'passthrough'
			],
		],        
		'sorting' => [
			'config' => [
				'type' => 'passthrough'
			],
		],        
        'hidden' => [
            'exclude' => true,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],
        'versteckt' => [
            'exclude' => false,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],

        'kategorie' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_kategorie.kategorie',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim,required'
            ],
        ],
    
    ],
];
