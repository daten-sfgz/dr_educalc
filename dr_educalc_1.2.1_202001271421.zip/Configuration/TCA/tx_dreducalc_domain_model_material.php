<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_material',
        'label' => 'tabellenname',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
        'enablecolumns' => [
            'pid' => 'pid',
            'disabled' => 'hidden',
        ],
        'searchFields' => 'tabellenname,felder,tabelle',
        'iconfile' => 'EXT:dr_educalc/Resources/Public/Icons/tx_dreducalc_domain_model_material.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'hidden, versteckt, tabellenname, felder, tabelle',
    ],
    'types' => [
        '1' => ['showitem' => 'hidden, versteckt, tabellenname, felder, tabelle'],
    ],
    'columns' => [
		'pid' => [
			'config' => [
				'type' => 'passthrough'
			],
		],        
		'sorting' => [
			'config' => [
				'type' => 'passthrough'
			],
		],        
        'hidden' => [
            'exclude' => true,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],
        'versteckt' => [
            'exclude' => false,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],

        'tabellenname' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_material.tabellenname',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim,required'
            ],
        ],
        'felder' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_material.felder',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'tabelle' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dreducalc_domain_model_material.tabelle',
            'config' => [
                'type' => 'text',
                'cols' => 40,
                'rows' => 15,
                'eval' => 'trim'
            ]
        ],
    
    ],
];
