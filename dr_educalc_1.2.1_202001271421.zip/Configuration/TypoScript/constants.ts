# customsubcategory=apersistence=Standard Speicher-Ordner
# customsubcategory=base=Bewertung bei falschen Einheiten und Zeitüberschreitung
# customsubcategory=cimage=Speicherort des Logos
# customsubcategory=exed=Aufgaben Editor
# customsubcategory=file=Speicherort der Template Dateien


plugin.tx_dreducalc_eced {
    view {
        # cat=dr-educalc/file/a; type=string; label=Path to template root (FE)
        templateRootPath = EXT:dr_educalc/Resources/Private/Templates/
        # cat=dr-educalc/file/b; type=string; label=Path to template partials (FE)
        partialRootPath = EXT:dr_educalc/Resources/Private/Partials/
        # cat=dr-educalc/file/c; type=string; label=Path to template layouts (FE)
        layoutRootPath = EXT:dr_educalc/Resources/Private/Layouts/
    }
	persistence {
		# cat=dr-educalc/apersistence/a; type=string; label=Default storage PID
		storagePid = 0
	}
	settings {
	      # cat=dr-educalc/exed/a; type=float; label=Aufgabe Edit Pid:Pid der Seite mit dem Aufgabe Editor-Plugin
	      aufgabeEditPid = 21
	      # cat=dr-educalc/exed/b; type=float; label=Material Edit Pid:Pid der Seite mit dem Material Editor-Plugin
	      materialEditPid = 21
	      # cat=dr-educalc/base/a; type=int; label=Gewichtung der Einheiten, in Prozent.:Prozentualer Anteil der Einheit an einem Notenpunkt. zB. 40 ergibt Note 4 bei fehlender Einheit (60% fuer Wert). 30 ergibt Note 4.5, 50 = Note 3.5.
	      gewichtung_einheit_prozent = 40
	      # cat=dr-educalc/base/b; type=int; label=Gewichtung der Zeitnote, in Prozent:Maximalabzug an der Punktzahl bei Zeitueberschreitung, prozentualer Anteil der erreichten Punkte (zB. 20 bewirkt maximal 1 Note abzug)
	      zeitabzug_maximalprozent = 30
	      # cat=dr-educalc/base/c; type=int; label=Prozent Zeitueberschreitung:Bei Ueberschreitung der vorgegebene Zeit um so viel Prozent wird der Maximalabzug geltend gemacht.
	      zeitabzug_maximaldauer_prozent = 100
	      # cat=dr-educalc/base/d; type=float; label=Zeitabzug ab Note:Minimale Note, ab welcher die Zeitueberschreitung bewertet wird (nach Abzug).
	      zeitabzug_ab_note = 4
	      # cat=dr-educalc/cimage/a; type=float; label=Logo in PDF-Dateien:Speicherort und Bildname, Pfad ab Web-Root. Beispiel: fileadmin/img/logo.png
	      logo_pfad = typo3conf/ext/sfgz_design/Resources/Public/Img/Logo/logo.png
	}
}
