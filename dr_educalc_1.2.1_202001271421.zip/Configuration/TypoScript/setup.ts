
plugin.tx_dreducalc_eced {
    view {
        templateRootPaths.0 = EXT:dr_educalc/Resources/Private/Templates/
        templateRootPaths.1 = {$plugin.tx_dreducalc_eced.view.templateRootPath}
        partialRootPaths.0 = EXT:dr_educalc/Resources/Private/Partials/
        partialRootPaths.1 = {$plugin.tx_dreducalc_eced.view.partialRootPath}
        layoutRootPaths.0 = EXT:dr_educalc/Resources/Private/Layouts/
        layoutRootPaths.1 = {$plugin.tx_dreducalc_eced.view.layoutRootPath}
    }
	persistence {
		storagePid = {$plugin.tx_dreducalc_eced.persistence.storagePid}
	}
	features {
        #skipDefaultArguments = 1
        # if set to 1, the enable fields are ignored in BE context
        ignoreAllEnableFieldsInBe = 0
        # Should be on by default, but can be disabled if all action in the plugin are uncached
        requireCHashArgumentForActionArguments = 0
    }
    mvc {
        #callDefaultActionIfActionCantBeResolved = 1
    }
	settings {
	      gewichtung_einheit_prozent = {$plugin.tx_dreducalc_eced.settings.gewichtung_einheit_prozent}
	      zeitabzug_maximalprozent = {$plugin.tx_dreducalc_eced.settings.zeitabzug_maximalprozent}
	      zeitabzug_maximaldauer_prozent = {$plugin.tx_dreducalc_eced.settings.zeitabzug_maximaldauer_prozent}
	      zeitabzug_ab_note = {$plugin.tx_dreducalc_eced.settings.zeitabzug_ab_note}
	      storagePid = {$plugin.tx_dreducalc_eced.persistence.storagePid}
	      aufgabeEditPid = {$plugin.tx_dreducalc_eced.settings.aufgabeEditPid}
	      materialEditPid = {$plugin.tx_dreducalc_eced.settings.materialEditPid}
	      tailrows = 3
	      amount = 15
	      hintwidth = 120
	      titel = <b>Prüfung Mathe</b> Version Nr. #VERSION#
	      dauer = <b>Dauer:</b> 40 Min.
	      bewertung = <b>Bewertung:</b> Max. #ANZAHL# Punkte. Abzug bei fehlerhaften Einheiten.
	      hilfsmittel = <b>Hilfsmittel:</b> Taschenrechner, zusätzliches Papier.<br>
	      logo_pfad = typo3conf/ext/sfgz_design/Resources/Public/Img/Logo/sfgz_logo.png
	}
}

plugin.tx_dreducalc_calc < plugin.tx_dreducalc_eced

json_view_dreducalc = PAGE
json_view_dreducalc {
  config {
    disableAllHeaderCode = 1
    debug = 0
    no_cache = 1
    additionalHeaders {
      10 {
        header = Content-Type: application/json
        replace = 1
      }
    }
  }
  typeNum = 1553191000
  10 < tt_content.list.20.dreducalc_eced
}

page.includeJS.educalc_ajax = typo3conf/ext/dr_educalc/Resources/Public/Scr/educalc_ajax.js
page.includeJS.educalc_helper = typo3conf/ext/dr_educalc/Resources/Public/Scr/educalc_helper.js
page.includeJS.educalc_calculator = typo3conf/ext/dr_educalc/Resources/Public/Scr/educalc_calculator.js

# these classes are only used in auto-generated templates
plugin.tx_dreducalc._CSS_DEFAULT_STYLE (
    textarea.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    input.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    .tx-dr-educalc table {
        border-collapse:separate;
        border-spacing:10px;
    }

    .tx-dr-educalc table th {
        font-weight:bold;
    }

    .tx-dr-educalc table td {
        vertical-align:top;
    }

    .typo3-messages .message-error {
        color:red;
    }

    .typo3-messages .message-ok {
        color:green;
    }
    .typo3-messages .alert.alert-warning { background:#B0D0FF }
    
    TABLE.math TD {text-align:right;}
    .dec, .int, .tinyint, .tinydec {text-align:right;}
    textarea.str {width:25rem;}
    input.str {width:25rem;}
    input.dec, input.int {width:5rem;}
    input.tinydec, input.tinyint {width:2rem;}
    TABLE.tx_dreducalc {border-spacing:10px 0px;}
    TABLE.tx_dreducalc TR {line-height:150%;}
    
    TABLE.tx_dreducalc TR.active A, TABLE.tx_dreducalc TR.active A:link { color:black; opacity:1;}
    TABLE.tx_dreducalc TR.passive A, TABLE.tx_dreducalc TR.passive A:link { color:black; opacity:0.4; }
    TABLE.tx_dreducalc TR.passive:hover TD, TABLE.tx_dreducalc TR.active:hover TD, 
    TABLE.tx_dreducalc TR.passive:hover TD A, TABLE.tx_dreducalc TR.active:hover TD A { color:#009ee9; }
    
    TABLE.tx_dreducalc p {margin:0;}
    TABLE.tx_dreducalc TD.sortbut { padding:0; }
    .pointer { cursor:pointer; }
    .changesort {display:none;}
    .scrollist {
		height:8rem;
		overflow-y:scroll;
		overflow-x: hidden;
		scroll-behavior:smooth;
		margin:0;
		padding:2px;
		border:1px solid #aaa;
	}
	.tx-dr-educalc P {margin:0 0 5px 0;}
	
	TABLE.calculator {border-collapse:separate; border-spacing:0;margin-top:2px;}
	TABLE.calculator TD.middleline, TABLE.calculator TD.bottomline { padding-top:5px; }
	TABLE.calculator INPUT[type='button'] { width:35px; text-align:center; }
	TABLE.calculator TD.middleline INPUT[type='button'], TABLE.calculator TD.bottomline INPUT[type='button'], INPUT.symbol[type='button']{ 
        font-size:7pt;padding:0; 
	}
	
	TABLE.calcbutt {border-collapse:collapse; border-spacing:0;}
	TABLE.calcbutt TD {padding:0 0 5px 6px;} 
	TABLE.calcbutt TD:first-child {padding-left:0;}
	TABLE.calcbutt TR:last-child TD {padding-bottom:0;} 

	.tx-dr-educalc .helptext, 
	.tx-dr-educalc .helptext-result, 
	.tx-dr-educalc .helptext P, 
	.tx-dr-educalc .helptext B, 
	.tx-dr-educalc .helptext P B, 
	.tx-dr-educalc .helptext U, 
	.tx-dr-educalc .helptext P U {
	  font-family:monospace;
	  font-size:100%;
    }
	.tx-dr-educalc .helptext-result {
        margin-top:8px;
    }
	.tx-dr-educalc DIV.helptext {
	  white-space:nowrap;
	  overflow:scroll;
	  height:auto;
	  margin:2px 0 0 0;
	  padding:3px 0 0 3px;
	  background:#eee;
	  border-top:1px solid #000;
	  border-left:2px solid #888;
	  background-repeat:repeat;
	  background-image: url( /typo3conf/ext/dr_educalc/Resources/Public/Icons/hintbg.jpeg);
    }
	.tx-dr-educalc .linedback {
	  background:#eee;
	  background-repeat:repeat;
	  background-image: url( /typo3conf/ext/dr_educalc/Resources/Public/Icons/hintbg.jpeg);
	  padding:5px;
	  margin:0;
	  border:thin solid #555;
	  border-bottom:thin solid #ccc;
	}
	
	.tx-dr-educalc .infolabel {
	  font-style:italic;
	  font-size:85%;;
	  border:1px solid black;
	  border-top:0;
	  margin:0 0 10px 0;
	  padding:5px;
	}
	
	.tx-dr-educalc .calc[type='button'], 
	.tx-dr-educalc .info[type='button'] { 
        cursor:pointer; 
        height:20px;
        width:20px;
        vertical-align:middle;
        padding:0; 
    }
	
	.tx-dr-educalc input[type="text"].result_value {width:12em; text-align:left; padding-left:2px; }
	.tx-dr-educalc input[type="text"].result_unit {width:4em; text-align:center; }
	
	.tx-dr-educalc .pager SPAN A:link, .tx-dr-educalc .pager SPAN A:visited {
        text-decoration:none;
        color:#ddd;
        background:#009ee9;
        border-radius:3px;
        border:thin solid #888;
	}
	
	.tx-dr-educalc .pager SPAN.selected A:link, .tx-dr-educalc .pager SPAN.selected A:visited {
        text-decoration:underline;
        color:#000;
	}
	
    @media screen and (max-width:801px) {
        .device-large {display:none;}
    }

    @media screen and (min-width:641px) {
        .device-small {display:none;}
    }

    @media screen and (max-width:501px) {
        .device-large {display:none;}
        .device-medium {display:none;}
        .tx-dr-educalc H1 {font-size:130%;}
        .tx-dr-educalc H2 {font-size:120%;}
        .tx-dr-educalc H3 {font-size:110%;}
         HEADER H2:first-of-type { font-size:120%; }
        .tx-dr-educalc .infolabel {
            margin:0 0 5px 0;
            padding:3px;
        }
    }

    /* Toggle Switch
    * source: https://www.w3schools.com/howto/howto_css_switch.asp */

    /* The switch - the box around the slider */
    .switch {
        position: relative;
        display: inline-block;
        width: 30px;
        height: 17px;
        margin-top:5px;vertical-align:bottom;
    }

    /* Hide default HTML checkbox */
    .switch input[type=checkbox] {position:absolute;top:-3px;opacity:0;width:1px;height:1px;font-size:1%;}

    .switch.disabled {opacity:0.5;}


    /* The slider */
    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        -webkit-transition: .4s;
        transition: .4s;
    }
    .switch.disabled .slider {cursor: auto;}

    .slider:before {
        position: absolute;
        content: "";
        height: 13px;
        width: 13px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        -webkit-transition: .4s;
        transition: .4s;
    }

    input:checked + .slider {
        background-color: #009ee9;
    }

    input:focus + .slider {
        box-shadow: 1px 2px 3px #005;
    }

    input:checked + .slider:before {
        -webkit-transform: translateX(13px);
        -ms-transform: translateX(13px);
        transform: translateX(13px);
    }

    /* Rounded sliders */
    .slider.round {
        border-radius: 7px;
    }

    .slider.round:before {
        border-radius: 50%;
    } 	
)
