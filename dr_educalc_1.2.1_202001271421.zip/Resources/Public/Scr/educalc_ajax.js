function updateByAjax( obj , fieldname , table , uid , URL ) {
		
		if( fieldname == 'versteckt' ){
            if( obj.hasClass('bulbon') ){
                var newValue = 1;
            }else{
                var newValue = 0;
            }
		}
		
		if( fieldname == 'filter' ){
            if( obj.is(':checked') ){
                var newValue = 1;
            }else{
                var newValue = 0;
            }
            if( $('#stop_filter').is(':checked') == false ){ $('.filtercheck').attr( 'disabled' , 'disabled' ); }
		}
		
		$.ajax({
		url : URL,
		type : 'GET',
		data : {
			'table' : table ,
			'uid' : uid ,
			'fieldName' : fieldname ,
			'newValue' : newValue
		},
		dataType:'json',
		success : function(data) {
			if( data[0] == newValue ){
					if( data[1] == 'versteckt' ){
						if(newValue){ obj.attr('title','Nicht publiziert'); }else{  obj.attr('title','Publiziert');  }
						obj.toggleClass( 'bulbon' ).toggleClass( 'bulboff');
						obj.closest('TR').toggleClass( 'active' ).toggleClass( 'passive');
					}
					if( data[1] == 'filter' ){
                        
                        if( $('#stop_filter').is(':checked') == false ){
                            $('.stop_filter.pointer').hide();
                            $('#ajax_result').html( ' ...Aufruf...' );
                            document.forms["aufgabe"].submit(); 
                        }
                    }
			}
			
		},
		error : function(request,error)
		{
			alert("Request " + error + ": "+JSON.stringify(request));
		}
		});
}
