// Set caret position easily in jQuery
// Written by and Copyright of Luke Morton, 2011
// Licensed under MIT
(function ($) {
    // Behind the scenes method deals with browser
    // idiosyncrasies and such
    $.caretTo = function (el, index) {
        if (el.createTextRange) { 
            var range = el.createTextRange(); 
            range.move("character", index); 
            range.select(); 
        } else if (el.selectionStart != null) { 
            el.focus(); 
            el.setSelectionRange(index, index); 
        }
    };

    // The following methods are queued under fx for more
    // flexibility when combining with $.fn.delay() and
    // jQuery effects.

    // Set caret to a particular index
    $.fn.caretTo = function (index, offset) {
        return this.queue(function (next) {
            if (isNaN(index)) {
                var i = $(this).val().indexOf(index);
                
                if (offset === true) {
                    i += index.length;
                } else if (offset) {
                    i += offset;
                }
                
                $.caretTo(this, i);
            } else {
                $.caretTo(this, index);
            }
            
            next();
        });
    };

    // Set caret to beginning of an element
    $.fn.caretToStart = function () {
        return this.caretTo(0);
    };

    // Set caret to the end of an element
    $.fn.caretToEnd = function () {
        return this.queue(function (next) {
            $.caretTo(this, $(this).val().length);
            next();
        });
    };
}(jQuery));

// resets trigger and inserts text at cursor position
function tryCalcDoInsOne(text , uid){
  $("#cleardisplay_" + uid).val(0);
  tryCalcDoInsert(text , uid);
}

// resets trigger and replace content with text or 
// or inserts text at cursor position
function tryCalcDoInsNumber(text , uid){
  if( $("#cleardisplay_" + uid).val() == 1 ){
    $("#cleardisplay_" + uid).val(0);
    $("#result_value_" + uid).val(text) ;
  }else{
      tryCalcDoInsert(text , uid);
  }
}

// inserts text at cursor position
function tryCalcDoInsert( val , uid ) {
  var obj = document.getElementById("result_value_" + uid);
  var startpos = obj.selectionStart;
  obj.value = obj.value.substring(0, startpos) + val + obj.value.substring(obj.selectionEnd);
  if( val.length > 0 ){ var strlen = val.length;}else{ var strlen = 1 ;}
  $("#result_value_" + uid).caretTo(  startpos+strlen );
}

// compute calculation and set trigger to 1
function tryCalcDoCalc( uid ) {
  var val = $( "#result_value_" + uid ).val();
  if( val == '' ) return;
  var raw = eval( val );
  var res = eval( Math.round( 1000000000 * raw ) / 1000000000);
  $("#cleardisplay_" + uid).val(1);
  $( "#result_value_" + uid ).val( res );
}


// fadeIn/Out Calculator
function tryCalcShow(attrId) {
    if( $( '.' + attrId ).is(':visible')  ){
        $( '.' + attrId ).slideUp( 300 );
    }else{
        $( '.jscalculator' ).slideUp( 300 );
        $( '.' + attrId ).slideDown( 300 );
    }
}

function toggleCheck( obj ) {
      $(obj).each(function() {
	if(this.checked==true) {
	  this.checked=false;
	}else{
	  this.checked=true;
	}
      });
}

// tryQuest compares users-result with given value
function tryQuest(uid) {
  var tryTest = tryQuest_numbTest(uid);  
  tryTest = tryTest + tryQuest_unitTest(uid);
  $( "#feedback_" + uid ).fadeIn(0);
  if ( tryTest == 10 ) {
	    $( "#feedback_" + uid ).html( "Korrekt" );
	    $( "#feedback_" + uid ).css( "color", "#0A0" );
	    $( "#result_value_" + uid ).css( "color", "#0A0" );
	    $( "#result_unit_" + uid ).css( "color", "#0A0" );
	    return;
  }
  $( "#result_value_" + uid ).css( "color", "#000" );
  $( "#result_unit_" + uid ).css( "color", "#000" );
  if (tryTest == 9) {
	    $( "#feedback_" + uid ).html( "Berechnung falsch, Einheit richtig" );
	    $( "#feedback_" + uid ).css( "color", "#F00" );
  } else if (tryTest == 8) {
	    $( "#feedback_" + uid ).html( "Berechnung fehlt, Einheit richtig" );
	    $( "#feedback_" + uid ).css( "color", "#F90" );
  } else if (tryTest == 6) {
	    $( "#feedback_" + uid ).html( "Berechnung richtig, Einheit falsch" );
	    $( "#feedback_" + uid ).css( "color", "#F90" );
  } else if (tryTest == 5) {
	    $( "#feedback_" + uid ).html( "Berechnung falsch, Einheit falsch" );
	    $( "#feedback_" + uid ).css( "color", "#F00" );
  } else if (tryTest == 4) {
	    $( "#feedback_" + uid ).html( "Berechnung fehlt, Einheit falsch" );
	    $( "#feedback_" + uid ).css( "color", "#F90" );
  } else if (tryTest == 2) {
	    $( "#feedback_" + uid ).html( "Berechnung richtig, Einheit fehlt" );
	    $( "#feedback_" + uid ).css( "color", "#F90" );
  } else if (tryTest == 1) {
	    $( "#feedback_" + uid ).html( "Berechnung falsch, Einheit fehlt" );
	    $( "#feedback_" + uid ).css( "color", "#F00" );
  } else if (tryTest > 0)  {
	    $( "#feedback_" + uid ).html( "falsch" );
	    $( "#feedback_" + uid ).css( "color", "#F00" );
  }
  setTimeout( () => $( '#feedback_' + uid ).fadeOut(1000) , 5000 );
}

function tryQuest_unitTest(uid ) {
  var ansUnit = $( "#result_unit_" + uid ).val().trim();
  var antwort = 4;  
  
  if( $('#units_' + uid ).length == 0 ) {return 8;}
  if( ansUnit == '' ) {return 0;}
  
  var aPossibleUnits = $('#units_' + uid).val().split(',');
  
  for(var i = 0; i < aPossibleUnits.length; i++){
     if( aPossibleUnits[i].toLowerCase() == ansUnit.toLowerCase()){
	  antwort = 8;
	}
     if( aPossibleUnits[i].toLowerCase() + '.' == ansUnit.toLowerCase()){
	  antwort = 8;
	}
     if( aPossibleUnits[i].toLowerCase() == ansUnit.toLowerCase() + '.'){
	  antwort = 8;
	}
  }
    return antwort;
}
function tryQuest_numbTest(uid) {
  var resVal = eval( $( "#result_value_" + uid ).val().trim() );
  var ansMin = $( "#answer_min_" + uid ).val();
  var ansMax = $( "#answer_max_" + uid  ).val();
  if( resVal == '' ){ return 0; }
  if( resVal >= ansMin && resVal <= ansMax ){
    return 2;
  } else {
    return 1;
  }
}


function initStoppuhr( sollZeit ){
    var startsek = new Date();
    var startzeit = startsek.getTime();
    stoppuhr( startzeit , sollZeit );
}
function stoppuhr( startzeit , sollZeit ){
    var aktuell = new Date();
    var zeit = (aktuell.getTime() - startzeit) / 1000;
    $('#dauer').attr( 'value' ,  Math.round(zeit) );
    $('.dauer_visi').each(function(){
        $( this ).html(  sec2min( zeit ) + ' von ' + sec2min( sollZeit ) + ' Minuten.' );
    });
    setTimeout('stoppuhr("'+startzeit+'","'+sollZeit+'")',1000);
}
function sec2min( zeit ){
  var minute = Math.floor(zeit/60);
  var sekundeh = Math.floor(zeit - minute*60) ;
  var sekunde = ("0" + sekundeh).slice(-2);
  var zeit = minute + ':' + sekunde;
  return zeit;
}
