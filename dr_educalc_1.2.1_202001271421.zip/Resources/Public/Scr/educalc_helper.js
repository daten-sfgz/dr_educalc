function initializeEntryfields( classname ) {
    // bind change-event to textboxes that stores the value on change, fill textfields with value
    $( '.' + classname + '[type="text"]' ).each(function(){
            $( this ).change( function() {
                    localStorage.setItem( $(this).prop('id') , $(this).prop( 'value' ) ); 
            });
            var oldValue = localStorage.getItem( $( this ).prop( 'id' ) );
            if(  oldValue > '' ) { $( this ).prop( 'value' , oldValue ); }
    });
     
    // bind change-event (click) on checkboxes
    $( '.' + classname + '[type="checkbox"]' ).each(function(){
        $( this ).change( function() { // change() instead of click() because of shiftSelectable
                localStorage.setItem( $(this).attr('id') , $(this).is(':checked') );
       });
        // mark checkboxes as checked/unchecked depending on stored values
        $( this ).prop( 'checked' , isTrueThenElse( localStorage.getItem( $( this ).attr( 'id' ) ) , 'checked' , '' ) );
    });
   
}
// ask bevore delete-behavor
function ask(url, message) {
  question = window.confirm( '«' + message + '» wirklich löschen?' ); 
  if(question) document.location.href = url; 
}

function unused_initializeTimer( timefield_class , sollzeit ) {
        var start = new Date;
        setInterval(function() {
            var passedSeconds = Math.round( (new Date - start) / 1000 ) ;
            $('input.' + timefield_class ).prop( 'value' , passedSeconds );
            $('span.' + timefield_class ).text(  '' + ( sollzeit - passedSeconds )  + ' Sek. ' + passedSeconds + '/' + sollzeit + ' Sek. ' );
        }, 1000);
}

function initializeToggleView( area_class , button_class  ) {
    $( '.' + button_class ).addClass( 'pointer' ).each(function(){
        $( this ).click( function() {
                $( '.' + area_class ).slideToggle();
                var oldValue = localStorage.getItem( area_class );
                if( oldValue > 0 ) { var newValue = 0 ; } else { var newValue = 1 ; }
                localStorage.setItem( area_class , newValue );
        });
    });
    var toggledValue = localStorage.getItem( area_class );
    if( toggledValue > 0 ) { $( '.' + area_class ).toggle(); }
}

function initializeCheckboxes( table_class , id_prefix  ) {
    // called by fluid template 'Aufgabe/List.html
    
    // bind shiftSelectable-event on checkboxes
    $( table_class ).find('[id*="' + id_prefix + '"]').shiftSelectable();
    
    // bind change-event (click) on checkboxes
    $( table_class + ' [id*="' + id_prefix + '"]' ).each(function(){
        $( this ).change( function() { // change() instead of click() because of shiftSelectable
                localStorage.setItem( $(this).attr('id') , $(this).is(':checked') );
                unCheckButtonById( id_prefix + 'all' );
       });
        // mark checkboxes as checked/unchecked depending on stored values
        $( this ).prop( 'checked' , isTrueThenElse( localStorage.getItem( $( this ).attr( 'id' ) ) , 'checked' , '' ) );
    });
    
    // initialize the controller elements 'toggle' and 'all', bind click-events to them.
    $( '.' + id_prefix + 'toggle' ).click( function() {
            toggleCheckboxes( table_class , id_prefix ); // includes shiftSelectable
            unCheckButtonById( id_prefix + 'all' );
    });
 					
    $( '.' + id_prefix + 'all' ).prop( 'checked' , isTrueThenElse( localStorage.getItem( id_prefix + 'all' ) , 'checked' , '' ) ).click( function() {
            localStorage.setItem( id_prefix + 'all' , $(this).is(':checked') );
            checkAllCheckboxes( id_prefix , $(this).is(':checked') );
            // following line permits to place more than one controller for 'all'
            $( '.' + id_prefix + 'all'  ).prop( 'checked' , $(this).is(':checked') );
    });
}
function toggleCheckboxes(  table_class , id_prefix  ) { 
    $( table_class + ' [id*="' + id_prefix + '"]' ).each(function(){
        // run binded event
        $( this ).trigger('click');
        // mark checkboxes as checked/unchecked depending on stored values
    });
}
function unCheckButtonById( button_id  ) { 
         localStorage.setItem( button_id , false );
         $( '.' + button_id ).prop( 'checked' , '' );
}
function checkAllCheckboxes( id_prefix , status ) {
    $( "[id*='" + id_prefix + "']" ).each(function(){
        localStorage.setItem( $( this ).attr('id') , status );
        $( this ).prop( 'checked' , isTrueThenElse( status , 'checked' , '' ) );
    });
    
}
function isTrueThenElse( bool_value , then_value , else_value ) { 
        if( bool_value === 'true' || bool_value === '1' || bool_value === true || bool_value === 1 ){
            return then_value;
        }else{ 
            return else_value;
        }
}
