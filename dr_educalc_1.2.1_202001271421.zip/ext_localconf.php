<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Dr.DrEducalc',
            'Eced',
            [
                'Kategorie' => 'list, new, create, edit, update, delete',
                'Material' => 'list, new, create, duplicate, edit, update, delete, fancytable',
                'Aufgabe' => 'list, new, create, duplicate , edit, update, delete, print',
                'Migration' => 'migrate',
                'Json' => 'update,session'
            ],
            // non-cacheable actions
            [
                'Kategorie' => 'list, create, edit, update, delete',
                'Material' => 'list, create, duplicate, edit, update, delete, fancytable',
                'Aufgabe' => 'list, new, create, duplicate ,edit, update, delete, print',
                'Migration' => 'migrate',
                'Json' => 'update,session'
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Dr.DrEducalc',
            'Calc',
            [
                'Run' => 'tryal, exam, result, certify'
            ],
            // non-cacheable actions
            [
                'Run' => 'tryal, exam, result, certify'
            ]
        );

    // wizards
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
        'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {
                    eced {
                        iconIdentifier = dr_educalc-plugin-eced
                        title = LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dr_educalc_eced.name
                        description = LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dr_educalc_eced.description
                        tt_content_defValues {
                            CType = list
                            list_type = dreducalc_eced
                        }
                    }
                    calc {
                        iconIdentifier = dr_educalc-plugin-calc
                        title = LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dr_educalc_calc.name
                        description = LLL:EXT:dr_educalc/Resources/Private/Language/locallang_db.xlf:tx_dr_educalc_calc.description
                        tt_content_defValues {
                            CType = list
                            list_type = dreducalc_calc
                        }
                    }
                }
                show = *
            }
       }'
    );
		$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
		
			$iconRegistry->registerIcon(
				'dr_educalc-plugin-eced',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:dr_educalc/Resources/Public/Icons/user_plugin_eced.svg']
			);
		
			$iconRegistry->registerIcon(
				'dr_educalc-plugin-calc',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:dr_educalc/Resources/Public/Icons/user_plugin_calc.svg']
			);
		
    }
);
