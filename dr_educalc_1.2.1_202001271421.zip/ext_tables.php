<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Dr.DrEducalc',
            'Eced',
            'EduCalc editor'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Dr.DrEducalc',
            'Calc',
            'EduCalc executing'
        );

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('dr_educalc', 'Configuration/TypoScript', 'EduCalc');

//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_dreducalc_domain_model_kategorie', 'EXT:dr_educalc/Resources/Private/Language/locallang_csh_tx_dreducalc_domain_model_kategorie.xlf');
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_dreducalc_domain_model_kategorie');
// 
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_dreducalc_domain_model_material', 'EXT:dr_educalc/Resources/Private/Language/locallang_csh_tx_dreducalc_domain_model_material.xlf');
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_dreducalc_domain_model_material');
// 
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_dreducalc_domain_model_aufgabe', 'EXT:dr_educalc/Resources/Private/Language/locallang_csh_tx_dreducalc_domain_model_aufgabe.xlf');
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_dreducalc_domain_model_aufgabe');


    }
);

if (TYPO3_MODE === 'BE') {
        $TCA['tt_content']['types']['list']['subtypes_addlist']['dreducalc_eced'] = 'pi_flexform';
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue('dreducalc_eced', 'FILE:EXT:dr_educalc/Configuration/Flexforms/flexform_eced.xml');

//         $TCA['tt_content']['types']['list']['subtypes_addlist']['dreducalc_calc'] = 'pi_flexform';
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue('dreducalc_calc', 'FILE:EXT:dr_educalc/Configuration/Flexforms/flexform_calc.xml');
}
