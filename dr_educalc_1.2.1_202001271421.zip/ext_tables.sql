#
# Table structure for table 'tx_dreducalc_domain_model_kategorie'
#
CREATE TABLE tx_dreducalc_domain_model_kategorie (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	kategorie varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	versteckt smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '10' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_dreducalc_domain_model_material'
#
CREATE TABLE tx_dreducalc_domain_model_material (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	tabellenname varchar(255) DEFAULT '' NOT NULL,
	felder varchar(255) DEFAULT '' NOT NULL,
	tabelle text,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	versteckt smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '10' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_dreducalc_domain_model_aufgabe'
#
CREATE TABLE tx_dreducalc_domain_model_aufgabe (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	titel varchar(255) DEFAULT '' NOT NULL,
	aufgabe text,
	antwort varchar(255) DEFAULT '' NOT NULL,
	toleranzwert varchar(255) DEFAULT '' NOT NULL,
	toleranzmin varchar(255) DEFAULT '' NOT NULL,
	toleranzmax varchar(255) DEFAULT '' NOT NULL,
	einheiten varchar(255) DEFAULT '' NOT NULL,
	zeitvorgabe int(11) DEFAULT '0' NOT NULL,
	punkte int(11) DEFAULT '1' NOT NULL,
	formeln text,
	hilfetext text,
	gruppe int(11) DEFAULT '10' NOT NULL,
	auf_mat int(11) unsigned DEFAULT '0' NOT NULL,
	auf_kat int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	versteckt smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '10' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_dreducalc_aufgabe_material_mm'
#
CREATE TABLE tx_dreducalc_aufgabe_material_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '10' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid_local,uid_foreign),
	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'tx_dreducalc_aufgabe_kategorie_mm'
#
CREATE TABLE tx_dreducalc_aufgabe_kategorie_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '10' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid_local,uid_foreign),
	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);
